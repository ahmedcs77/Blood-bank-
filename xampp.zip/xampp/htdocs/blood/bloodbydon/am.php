<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<?php
include("../../auth/db_connect.php");
// $query="select count(*) from donors where blood_group =".'2';
$query="select count(*) from request r , patient p
where r.p_id=p.p_id
and r.check=0
 and p.blood_group=".'2';
// echo $query;exit();
$result=mysqli_query($conn,$query);
$row=mysqli_fetch_array($result);
$_SESSION['am']= $row['0'];
mysqli_close($conn);
?>
</body>
</html>