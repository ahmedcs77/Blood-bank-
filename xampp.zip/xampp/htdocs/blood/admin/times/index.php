<?php

$currentDateTime=date('Y-m-d || H:i:s');
    $day=date('w');
$currentDate = date("Y-m-d H:i:s");
echo "التاريخ الحالي: " . $currentDate . "<br>";
$arabicDaysOfWeek = [
    0 => "الأحد",
    1 => "الاثنين",
    2 => "الثلاثاء",
    3 => "الأربعاء",
    4 => "الخميس",
    5 => "الجمعة",
    6 => "السبت"
];

$dayOfWeek = date("W"); // يتم استخدام القيمة الحالية لليوم من الأسبوع
$arabicDayOfWeek = $arabicDaysOfWeek[$dayOfWeek] ?? "";

echo "اليوم الحالي : " . $arabicDayOfWeek;
// التاريخ بعد 6 أشهر
$futureDate = date("Y-m-d H:i:s", strtotime("+6 months"));
echo "التاريخ بعد 6 أشهر: " . $futureDate . "<br>";

// تفاصيل التاريخ الحالي
echo "التاريخ الحالي: " . $currentDate . "<br>";

?>