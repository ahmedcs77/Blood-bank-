<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
    if(isset($_POST["signin"]))
    {

      //   echo "entert";exit();
    session_start();
    $email=$_POST['email'];
    $pass=$_POST['password'];
    include("../auth/db_connect.php");
    
                  //   echo"user";exit();

        $query = "select * from users where email ='".$email."' and password='".$pass."' and type='0'";
      //   echo $query;exit();
         $result =mysqli_query($conn,$query);
         $rows=mysqli_num_rows($result);
         // echo $rows;exit();
         if($rows>0)
         {
          $_SESSION['type']=2;
            $row=mysqli_fetch_array($result);
            $_SESSION['user_id']=$row[0];
            // echo ''.$row[0].''.$row[1].'';exit();
            mysqli_close($conn);
            
            header("Location:../admin/index.php");

         } 
         else{
            // echo "didnt find";exit();
            $_SESSION['error']="اسم المستخدم او كلمة المرور غير صحيحة";
            // echo $_SESSION['error'];exit();
            header("Location:../admin_login.php");
         }   
        
    }
    else{
      header("Location:../admin_login.php");
        
    }

    ?>
</body>
</html>