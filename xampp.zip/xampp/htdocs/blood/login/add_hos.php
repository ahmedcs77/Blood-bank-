<?php
session_start();
 if(isset($_POST["add"]))
{
    // echo"hhhh";exit();
    
    include("../auth/db_connect.php");
    $name=$_POST['name'];
    $city=$_POST['city'];
    $address=$_POST['address'];
    $email=$_POST['email'];
    $password=$_POST['password'];
    $floor=$_POST['floor'];
    $query="insert into hospitals (name,city,floor ,address,email,password) values ('".$name."','".$city."',".$floor.",'".$address."','".$email."','".$password."')";
    $result=mysqli_query($conn,$query);
    $query="insert into users (username,email,password,type) values ('".$name."','".$email."','".$password."','.2.')";
        $result=mysqli_query($conn,$query);
    // echo $query;exit();
    mysqli_close($conn);
    $_SESSION['success']="تنبيه: تمت اضافة مستشفى";
    header("Location:../admin/index.php");
}
?>