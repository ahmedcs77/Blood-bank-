<html>
<?php
session_start();
if(count($_POST)>0)
  {
  $_SESSION['type']=$_POST['type'];
  // echo $_SESSION['type']; exit() ;
  header("location:http://localhost/blood/login.php");
  }
  ?>
</html>

