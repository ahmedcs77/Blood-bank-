<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;
require 'mailer/mailer/phpmailer/phpmailer/src/Exception.php';
require 'mailer/mailer/phpmailer/phpmailer/src/PHPMailer.php';
require 'mailer/mailer/phpmailer/phpmailer/src/SMTP.php';

if (isset($_POST['signup'])) {
    # code...
$name=$_POST['name'];
$email=$_POST['email'];
$passwords=$_POST['password'];

if($name!=''&&$email!=''&&$passwords!=''){

    $mail = new PHPMailer(true);

    $mail->isSMTP();           
    $mail->Host       = 'smtp.gmail.com';                    
    $mail->SMTPAuth   = true;                                   
    $mail->Username   = 'blood00bank@gmail.com';                   
    $mail->Password   = 'rgekcnzwcvwqzdud';                               //SMTP password
    $mail->SMTPSecure = 'ssl';            //Enable implicit TLS encryption
    $mail->Port       = 465;                                    //TCP port to connect to; use 587 if you have set `SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS`

    //Recipients
    $mail->setFrom('blood00bank@gmail.com');
    $mail->addAddress($email);     //Add a recipient
    $mail->isHTML(true);                                  //Set email format to HTML
    $mail->Subject = 'Send to code form blood_bank ';
    $mail->Body    = '  <div style="
    margin: 0 auto; 
    padding: 20px; 
    max-width: 600px; 
    text-align: center; 
    border: 1px solid #f00; 
    background-color: #f9f9f9; 
    border-radius: 10px;">
    
    <!-- شعار الشركة -->
    <img src="data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxANEg8SEBANDhAPEBAQDw8NDQ8PDxAQFRIWFhYSFhUYHCggGBolHRMTITEiJSkrLi4wFx82ODMtNygtLisBCgoKDg0OGxAQGi0dHSIuLS4rLS0tLS0tLSstLS0tKystLS03LS0tKy41LTUtLS4tLSstLS0tLS0tKy4tListK//AABEIALIBGwMBIgACEQEDEQH/xAAcAAEAAQUBAQAAAAAAAAAAAAAABwIDBAUGAQj/xAA4EAACAQIDBAYJBAIDAQAAAAAAAQIDBAURMQYSIUEiUWFxgZEHExQjMqGxwdFCUnKSYmNDgsIV/8QAGgEBAAMBAQEAAAAAAAAAAAAAAAMEBQIGAf/EACMRAQACAgICAgIDAAAAAAAAAAABAgMRBCESMQVhE0EiQvD/2gAMAwEAAhEDEQA/AJxAAAAAAAAAAAAAAAAAAAAAUVasYRlKTUYxTlKUnkkks22yDNqPSFO5vYujOdOjQllRybXSWs32v6cOs3fpi2z3U7KhLj/zyi9X+zuXPtyRDtOk5Jvj39vWVc2XXTY4HDm0eUx3Pp9R7KY9DEaKmslUjkqsFyl1rsf5N0fO+wG1E7OrF555dGpDPhOHNfjtPoGyuoV4QqU3vQmlKL+3eTY7+UKPKwTit9L4AJFUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADl9v9p44Zbyaa9dUTVNftXOfhy7ToL+8hbU51aj3YU4uUn9l2nzbtztDUxK5m23lnkop5qMV8MURZb+MLnD485b/UNJKU7uq5NtuTbbfHJa8TZu1UY5Gdh2Heogs105pOXYtUvv5FFy+Jk5rvefH8WIjctHVi6UlOPLXtRLPov2sUWqNSXu6rW62+EJvn3PQjWvTTLOG3Lt6iX6W+HYyfj5mZ8twI1Mx6fVQOW2C2hV7RUJyzq0ktXxnDlLv5M6k04ncbeMvSaW1IAD65AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADnttseWH28mnlVqJxp9a65+H4PkzqNuq1m06hwPpe2szbtqUujTfTyfxVOruX1zOB2Wwvfcq9RZxg81n+qfJGJGnUxG5UY5vOWv1Z2d3CNGMaUPhprLvlzZQy2329TwsMY4ise/8AdtddVNW9WaqbzZlXlQxDOvO5ev4tPGi1UMO4hmZszGqo6pOkPJp5Rpvti8enbVIST6UHpnwkuafY0fQWHXsLmnCrB5xms+1Pmn2o+V6dR05KS8SX/RjtGotUZy6FVrdzfCNTl56eRqYMm3hvk+J4zuEpAAtsQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABTUmoJyk0oxTbb0SWrPn70lbSSu60t1vd+ClHqgtPF6+JJnpNx5W9H1MXlOqs55PSHV4v6ES7I4S8QuXVmvdUXnx0civltv+MNPg4orH5LN3srhPsNv62a99WXDPWMTFvaupvMduU3kuEY8Ejlb2qUs066ek+PxzafKf2w60s2UnmZ6UZeppGoUSLFRF+RamdVQ5YYdaJsdn7505JZ6MwqiMeMtySaLeK2mBzsPlD6Z2RxhXtCLbzqQyjU7Xyl4/k3ZCvo+2g9nqwbfQl0Ki/wAXz8NSaU8+K4p6NGnS24eM5GL8d/p6ADtXAAAAAAAAAAAAAAAAAAAAAAAAAAALVzXjShOc3lGEXKT7Ei6cR6TcY9TSVGL41OnP+C0Xi/ofLTqNu8dPO0VRdtpitS+ryy4zrT3Yx6lol3JfQ7PDcPjhtpGmvjazk+bbOc2Awr2m4nczWcKWcYZ6OXN/bzOi2ju821yRV/Xk2ojdoxx6j25rEK2pobmebNhfVdTUzebM/LO3reDj1D1HpSj0rtaHjLci4y3I6hFkWJoxqsTKmWKiJqyzM9ds7AbvcaWZPuwmLe00FCTznRyj2uH6X9vA+cKM9ySZJewWNez1acm+i+jP+L5+HB+Bfw3eV+Q4+96TSAmC4wQAAAAAAAAAAAAAAAAAAAAAAAAAAeSkkm3wSWb7iCNuMTld15uOtSe5TXVHSPy4kt7Z3/s9rUyeUqnu48evX5JkQbPW3tV7HPjGn0vF6fchyzvpf4ddRN5dzg9lGxtIQXB7ub62zk8Wr5tnY49V3Y5LqOAxGepBmnUaaXx9fK3lP7ai7mYKZfuWY0TOv7ew4/VVxHpSme5ka5EjKJFTKJH2HF5W5FmZekWZktVHKxqh0Gz11oaCoZWEVd2XiWccsPmV3D6Q2OxH2m2hm85U/dy8Phfll5G8I09GmI7tR02+FWOn+UeK+W8SWaNJ3DyuenjeYAAdIQAAAAAAAAAAAAAAAAAAAAAAAEd+lK9406a0jBzffJ5f+fmc/wCjmhxq1Hzby8OB76RLnfuK/ZLc/qkvszL2Fju2+fWs/Mr+7tSI8cGmXj9XU4m/lqdVjc88zkb16kOVpcDpqLhliLLtwzHiyhaHqMFul1M9zKEz3M40tRZ62UNnrZQ2fYhxaymTLU2VyZakySsKWWyzM9tJZTRTNlNF9JE9GXn7hImy146U6c1rCUZeTzJ1hJNJrRpNdx884HPQnbZ2t6y2t5f61H+vR+xexS81za9xLYgAmUAAAAAAAAAAAAAAAAAAAAAAAAEHbYycqtdvV1amf9mbfZKeVuu5GFtvQ3bi4X+yb8G819TzZSv7tx6l9Ct/Zrz3ihfxeWpy14zosUlqc3dkWRd4k6aq4ZipmRcGJmVLQ9Bhv0vJnuZaUj3eI9LUXVtlDZ45FDkfYhxa5JlqTKpMtSZJEKmS6ibFvxkimTLthHORNWGdms63BVoTVsPVcrVJ6QnKMe7hL6yZDWDw0Ju2Tp7lpQ4ZNxcu/OTaflkW8Xthc2em3ABOzQAAAAAAAAAAAAAAAAAAAAAAAEZekmy3a+/yqwT8V0X9F5nIYDX9XUlF6N/UljbvDvX2++lnKi97/o+Evs/Ahy7i6c1Jcn8iveNWavGt549N1iT1OdupG5q1/WQUl1cTRXb4kdlrDOmuuGYUnxMu4Zg1GVrVa+HJ0rUj3eLKke7xx4rUZVxyKXIo3ilyEQ5tkVORbkzxyLcpEkQrXyEmbTC6OhrrenvM6XDLfQkrCjls3+D0G3FJZttJLrbJys6HqqdOC/RCMfJZEabBYZ62vGTXRpe8l3/pXn9CUS3jjph8u+7aAASqgAAAAAAAAAAAAAAAAAAAAAAACmcVJNNJpppp6NPkQ/tfgbtaso5PcfSpvri/utCYjWbQYPG9pODyU1xpz/bL8M4vXcJ8GXwt9IHo1XSbi/hZj36y48uRvMawqdKcoTi4zi8mn9V1o0VROPRlxXX1FaWvWYnuGqrSMGszOuqTjpxRr6rI5hapaYUKR7vFlg50n/JK65FLkUAafJyS9bPYQcmV0qDkbaystOB1EIrXMPtNDqcMtNOHF9Rj2NnoSbsPs3u7txVjlzowev8AN/bzJqV2oZ80Vjcug2Xwn2Oiote8n0qnY+UfD8m4ALMRpjWtNp3IAD6+AAAAAAAAAAAAAAAAAAAAAAAAAAA0+0OAU76PHoVI/BUSzf8AF9aIox3AKttJxqwcXyesZLrT5k3li8tKdeLhVhGpF8pL5rqZxakSsYeRNOv0+c7mxaNXcWPYTXjOwOecraaf+uq+PhL8+ZxeJ7O1qDfrKU4cs3HOPhJcGV7UmGnj5NbepR3OwfaW/Ypdp2U8O7C3/wDN7DjxWIzOUjYvtMqjh3YdJHDuwzLTCpTaUISnJ6KEXJ+SPsVczmaK2sOw3Nlh7bSSbb4JJZtvqOvwjYW4qZOolQj1z4zy7Ir75HdYLs9Qs0nCO9U51Z8ZeH7fAlrjlTy8useu3PbK7Hbm7VuY6cY0X8nP8efUduATxEQzb5JvO5AAfXAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAGgANNjOHUGk/U0M2+L9VDN+ORHeKUoxqSUYxis9EkkAQ39r3HmZh1WzthRmqe9Royz13qUHn5o6+jRjTWUIxguqEVFeSAO6ekGeZ8lwAHaAAAAAAAAAAAAAAAAAAAH//Z" alt="بنك الدم اليمني" style="width: 120px; height: auto; margin-bottom: 30px;" />
    
    <!-- اسم الشركة بالكامل -->
    <div style="
        font-size: 20px; 
        font-weight: bold; 
        color: #f00;">
بنك الدم اليمني
</div>
    <!-- اسم الشركة بالكامل -->
    <div style="
        font-size: 25px; 
        font-weight: bold; 
        color: #f00;">
اهلا وسهلا بك في موقعنا يا:'.$name.'
</div>

    <!-- عنوان رسالة التحقق -->
    <h1 style="margin: 20px 0;">رمز التحقق الخاص بك</h1>

    <!-- رمز التحقق -->
    <div style="
        font-size: 30px; 
        font-weight: bold; 
        color: #333; 
        margin: 20px 0;">
      <b>  123456 </b>
    </div>

    <!-- التعليمات حول استخدام رمز التحقق -->
    <div style="
        font-size: 18px; 
        color: #555;">
        استخدم هذا الرمز للتحقق من حسابك.
    </div>

    <!-- ملاحظة حول عدم طلب رمز التحقق -->
    <div style="
        font-size: 14px; 
        color: #777;">
        إذا لم تطلب هذا الرمز، يرجى تجاهل هذه الرسالة.
    </div>
    <div style="
        font-size: 15px; 
        color: #d00;">
   سيتم الغاء تفعيل الكود بعد 3 دقائق
    </div>
    
    <!-- شريط الروابط -->
    <div style="
        margin-top: 10px; 
        padding-top: 15px; 
        border-top: 1px solid #fff; background-color: #d00; color:#fff; border-radius: 10% 10%;">
        
        <a href="/about" style="margin: 0 10px; color: #fff; text-decoration: none;">
            عنّا
        </a>
        
        <a href="/contact" style="margin: 0 10px; color: #fff; text-decoration: none;">
            تواصل معنا
        </a>
        
        <a href="https://www.linkedin.com" style="margin: 0 15px; color: #fff; text-decoration: none;">
            <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAOEAAADhCAMAAAAJbSJIAAAAb1BMVEX///8AZsgAWMQAY8cAWcTs8voAXcbz9/zh6vcAYcdBf9Cqwef7/f8AW8UAYsdumdgAVcRkk9Z1ndrG1u96oduQsOCuxei2yuozeM5PhtIUbMoncszD1O44e86Bpd3c5vXQ3fGJqt6dueMAUMJYi9SQ2xJeAAAEuElEQVR4nO2d63aiMBRGgYRoKlAoXsFLO9P3f8ZBnTpKQnTN4uQIfvuvUbobyI3knCAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADAoIjL2WJebNZVpqJeUDqsd5tivliWE265ICjnVZQqnWVCiLA/ml/LtFZpVO1LTr3pPk11n2IWVS3VfsrkFxe5JrX7QedFzCG48OR3dlx494tr5c3viKo9V2MpaR8/EyG9NjnL3LPfkXw5ckGfiiWPYKPo6UaNJZNgGEZ+mpvadyPzD1H7EFz47SZuUR76xZjrITyT09+nhb+RjA1dUAtOeauwqUTqYfietwqbStwTG3I2M2dSWsGSry+8GNJ2++w3aXObzkkNK77e/gdRUQpOIm6/kHjoVqbceiHxg7jkb0qbkduM0HDB39A0TQ3l2HR+37DfdVMb2QehYZG5L65TWb/VUpJWdUY5NN0460fkxeep2Od7TliRYkNouHP94bo6XApOa7pqFGtCQ9f0Xr/dFN3QKVJ2+Y7LGkMNusWOjNDQUS/RZ6vsgWwmqQgNuzv8zHz87zW8/01EaNg9LFVbozDZEI/HMDLf1iZUw3QeQ20pXY3KMLSUpmpNmZ5DS2kaP7bn0JyWkk2XmerQfPO1pZpM8hiKnVHYPUwfnGEo2x1iSbamw2QY6tseMaGbP3EZiupacUL4lpHLMBRqdSm4pdwqxWbYPIvr2fHNULxcky7+Mxo21SillpGiXYziNPQDDGEIQ34GZSj0373hUj3eg3IZytZ+dNn1yWXKIVS++1od4iRJ4sPqa50/OBnhGnnHQXJD/FNYHm4+CVZnESHr2e1QNv4VPuTIZGhMgS8TYNnaAXM2TGtzdS4IZuqBJchBGGZpx17RpLj/rA/BUO26j4qs7ioOwFC+uy4yvdeqPr/h7zsbt+5t0X16w+Xdd7hb94369IYPbBZ5d758fHrDB3AvtY7BMPhyVeIoDJ2VOArD4MMxthmH4cF1qT5UOvBn6NrnORjDyWpfbL7nS/tmSkdbMxDD6XeudCYyrfJvm6PjzdUwDH/l/5qSLF+ZBeLuaw3CcHH7SzbF7sHpEAyN832Wwz7DbmmMb2tzPuW4FJHdkZ4Ml+ZeoihpFxq04Zt5B6bGqs2QDRPLnj5z8/aQDT8tzaR5EmbIhrYzDWZTM2TDGQxPwJAGGF4DQxjCkAYYXgNDGMKQBhheA0MYjs7QOIIOQxpgeA0MYfjKhpSxsBwbXD0aUp7Hd20B8WdoO3PcF64NEt4MSQNgrp/C0Dyu2h+Og69GyIFLwAHZdre+mXn83RNpfBpHqAvx1ubnvyF2rQ9q2/er9tc7r0QaY2juaGpEm85PHvt+54VIg+6NP9aXrY3wDmm8tvHH3HNsxfKHJVBMj4w+9uUjQfeoIQ6z+wQPInWOBH5DypnFEfYwu+SxoMcfz3v8MdlfIK7++HMjvEB+C86hm6ccJcF27HlmXiBX0Avke2LJ2RXZIhQQMvq8a8H4c+cFL5D/MDjmsFSSPIdlypfD8kS5P+Uh1T3nIQ2FyLJTHtI5ax7SM5NzLtldHTZ/UT/JZEW13hQfi1nJdXcCAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADgP/kDjnplWREBPBIAAAAASUVORK5CYII=" alt="LinkedIn" style="width: 30px; height: auto;" />
        </a>
        
        <a href="https://www.facebook.com" style="margin: 0 15px; color: #fff; text-decoration: none;">
            <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAOEAAADhCAMAAAAJbSJIAAAAe1BMVEUYd/L///8kffMAb/EAbfEAcPEAavEAafGpxfkAcvLE1/u5zvoKdPLx9v7a5vzl7v1nnPWvyfk3hPPR4PyErfe80vr4+/9MjfR9qfbK2/ubvPhRkPRDifNxovZimfWVuPiMsvfv9P7i6/1uoPUvgPOIsPc9hvOiwPhalfXW6xCvAAAKfUlEQVR4nN2d6XbjIAyFccA4TmlWO1uzNGk77fs/4eBszeIFENdk5v7qmTNN/cUgJBASi+CaDiZ5d5utN2+zP59a49XqZ7jOtt18Mpji/zxDfvhg8T1fKSkEj1NViB2lf0pVGnMhpJrNv3sD5EOgCAcvXzMhBb9QVUmpWMj47T1HYSIIB6M1kzxtYrvhTLlk6xGC0jvhIutIbgN3hcllJ1v4fiCvhNN8KETqRHdWKsTwxav98UiYbwSn4Z0guRj2/D2WL8J+xoXb2CyFFHze9/RkfghHY+nj7d1AyvHIy7N5INx9CUfTUi/FxfvrExDuPxLfr+9XcfKxD0zY/0kQr+9XafJDnJAkwv6PxPIVUpLGSCAcDFvgOzIOCc6OM+E0824+6xgzZy/AlXDE49b4CsW82yphfyxa5Sskxm7T0YlwDjag5VLJvCXChWp3gP4qZg6Rhz3hWgbiKyTXcMIJa8+ClilmEyzhexKUr1CyBRK+rnhoPi2+svLHbQgXkBDCXorbjFQLwmX4EXpWskQQDttf5Kslht4Jp+NQi2C54rGpo2pIuG/c2W1bShnGG2aEE4+7TL6khJm9MSLMn8fGXCvJfRF2nxNQI5pEVAaEy5COaL3ktw/CJwbUiM0LYyPhUwOaIDYRPjmgwUBtIOw+O6A2Nw2b//WET7pM3Kph0aglnPwLgBqxdumvI9w/k69dJ1HnwNUQTp/OF62SUjVueA3h+F8B1IhjF8Lhc4VL9Yqr48VKwuW/MgmPEpUrfxVhW2ZUpUVmlBRxkTIVS/2TVhynVtk4hSoNagXhaxubaooL/pZ1e/3dr6F4HfQnvdEyG86YpuWxubWLK3bgKghXcCuTirQpB2o3eVmuV9zwy1YrG8J38CtUIs2MdwRHhiaPl28VlxKCJ6GSM5uMoBfTrzspPX4rJQTzWZ7LGxOycpiSf1sjV0Ixtj1aMSeMy06mSggXwIhJCfvDaot3KEvOF0sIgWaUr3bWgDaETJkQznFjVH7Z89kRxlkzYR9nR5MXF0ArwhJ7+kCIiyikrYlxIXyMMu4JRzCH2xXQjpCJ+22bO8IpzJlJnBO47QgZv4uG7wgzlJmRrilN1oT3xuaWcIBaCkvXYgwhk7sawiEolUR9ugNaE6rbeP+GsI96hZJyVcSWkMmbvOIbwh/QShFbpsAQCdVPFSHsFdJSra0Jmbxe9q//OOoVCqOzWo+EalNOuAf5a3WbmRhCllzNxCvCj+d8hS6E6qOMcAdzuWmALoQs2ZUQfoHWQm5w1u6dMH0vIUS53An1Zo8LIeOPhCOQz31j11okvIQYF0JUXMjdwl4q4a8BPxPiHDbyhVAnwt9V/0w4R/ncFXvtcML0HESdCVGRr4NLOn290dTRQpxtzYkwR1lSYRXa95fDTyHv5Pjli94N4Qa1/2QxDV/flYitzw0rlQ6vCaewqKJjDPguPe+giOkVodtkNlD6UQd1pUHH+w4Rz68IYYPU1ND0AZc1T8P0SAjbJDVc7weQBxC/hD0YoWEudgcyho52/ECYwW5r1eZjXbTFmIHjon8g7ED+QCGjxWKKGkKdMyFsH/g8FRq0RFnywyZmQWia7OCg2IQQMwvZKYQqCD+AlyYNAHFDSK1PhMBjbROXBhV7FzoSAqehESHOkh8OaRjQZWNmhKiNaHZ03Bhuk62QCSEwU7fYctOEs8DzELcaM/V2IESmygYmLNZjBvJ6TwpNqNd8BnS7WXhC0dOES2SeXmjCeKkJ18h04NCE2qth2ITn4IQrTQi9VhGaULv+DLfNVig4oZwy7PWt4IRizyb/OeGE5dCLB8EJec66/7el4V22hVZFCk6YblkGvf8TnFBlDOrSPAHhmsGOLA4KT7hhb/854RtbIT//CQhnbIz8/PCE7A/7hH5+eMJPD4QqrhQ32fNmvPoDtIh24pORv0GVjbrVMiCs+W2tETF+7dAJ7fJJ7EXcTvUwSoXHGvhlIsY+n9rWPDchdbPzD309BBMuiIQruk8DJuzS4lft05D9UjAh8exN+6XkDH0wIXGM6diCHB+CCYmPp+NDcoyPJaRuduoYn7xPgyXsE01p3KXvtWEJqUfwPGfU9QZMuCUOMTGh73ljCam5PmJPP7fAElLTGOSUkbP0sYTUERZ7OD+EElL97sP5IXXDFEpItYOHM2DqOT6UkLpax99FLgZxIkIJqTlvh1wM6lCHElJju0M+DdVcQQmpYQH3kdeGJKQu1qe8NmJuIpKQ6nefchOJvjeSkBoWnPJLiTnCSEKq333KESZOZyQhOcc+8pGrjyQk+t2XXH3afQskIdGUXu5b0CYikHBHJLzcmaGd4AEJqX735d4TzfsDEhL97qu7a6REaODpGtHvPn73Hu6QxqJaJbUoH6Sqf5sEeH2HFFfFzOgcH5TvcnMPGHYxKGSmws1dbliicEjCm/v4sOvqAQlvayrA6mIEJLyri4GqbRKQ8K62Cao+TTjCh/o0oBpD4QgfagyB7jkGI3ysEwW6bxyMsKTWF+aiZTjCy8eDa+6FIozLau5B6iaGIrwq9HeVAIpwvwMRlte+hCwYgQgr6pcirv6HIayqQYt4iWEIK+sIk8+yHhWE8LbcJriedxDC61l4X5N949uchiCsq8nuv5BLCMK7AvDg3ggBCOt7I3jvbxGAsKG/he8eJe0TPrRbAveZaZ2wuc+M515BrRMa9Arya2zaJjTp9+S3uFnbhEY9u7z2XWuZ0LDvWrT259m0S2jaO89n/8OW32EpTNk/+uth2SqhRQ9LfyVT2yS06UPqr5dsi4R2vWS99QNukZDb9QOOFn6mYnuEtj2dffXlbo1QVPZ6AfdWb4vQpbe6nyijJcK6llI1hFPzrt+BCZWqKapdV9bBQ6Gzdghr66LXFq6gG9RWCCvNaDNh9EJFbIMwqe961lB8pEuMpFogbOpw2lReZUlDxBPKZcPHNxaQ2ZIQ4YSNgM2ENEQ0oWzugWJQBIgyUMGEzW/QiDDqultULGFiUsLIqP1i7owIJWxYJmwIo4lrQjKQUBn2sDFsoTlw9FFxhEoZdlE2bRI6HTsFUzDCeGza7sy8DerQxQ9HEYrqeNCdMFo62BsQYWKwSjgQRgtuPRkhhIqb2Rh7wuh1ZbsFhyDkK6vutJbtiLeWIxVAmFh2xbRtuNxnVjbVO2HMbEaoC2EUrW3cVN+Esux0yTdhtFDmr9EvYawc7sk5tQWfJ6ZG1SehSuYuD+vW+Lw/Nlz+PRKKcenhWaNcW7uPuNFQ9UYYc5NIqUzOzeunmUnrUE+EaZI5N792Joyi3bCZ0QuhkhvDOKJMBEI9HX+aGD0QKvnjNgFPIhFqxk29WSUTpvKNxEcmjKL9R1KTnEIkTJMhkc8DoZ6PX6Iy6KAQKi6+dvTH80CoNRrL8hfpTpjK8aj5dw3kh1BPyIyX7VY5EqaCz8nD8yRfhFr5Rj6MVhfClIuhx0oUHgm1F/CyESIlEaZCbHLn1b1MXgkL9bKO/K32b0WoYtnJvFfZ8E6oNRitleSpsiBUKZfqY0RwXSqFICw0yL9mQgij7g/6/82+XhB0h48Hfe5Bg7wyj+dK3z0U3EFQwqfQXz+MoYvKFDQjAAAAAElFTkSuQmCC" alt="Facebook" style="width: 30px; height: auto;" />
        </a>
        
        <a href="https://www.instagram.com" style="margin: 0 15px; color: #fff; text-decoration: none;">
            <img src="data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBw8NEA8NDQ0RDg0OEQ4NDw4QDRAQDQ4NFxMWFxcRFRcYHSggGholHRUTITEhJSkrLi46Fx8zODcsQygtLisBCgoKDg0OFRAQFS0fFSUuLSsrNysrLS0rLSsrLi0tKystLS0tKysrKystNy0rKzAtKy0tKystLysrLSstLS0rLf/AABEIAOEA4QMBEQACEQEDEQH/xAAcAAACAwEBAQEAAAAAAAAAAAABAgADBwYEBQj/xABMEAACAQIBBwQIFQMEAwEAAAAAAQIDBBEFBgcSITFhQVFxgRNUcpGTlLGzFBUXIiMkMjM0UlNzdIKhosPR0tPjQmKSVWOkssHh8UP/xAAbAQEBAAMBAQEAAAAAAAAAAAACAQADBQQGB//EADkRAQEAAQEDBwkHBAMBAAAAAAEAAgMEESEFEjFRcaHRExQyQYGRscHhFSIzQlNh8FJykvFiouIj/9oADAMBAAIRAxEAPwD4IL7uAa0DWBK0JWhlkUyJZWxkBIpWxkBIJWxkBIJWxkBIJWxkBIpWxkBIJWRkBIJWRYUilZFhSKVkWBIpWJh3QSdMKUnTIkd06YUjMmGkyZKTJkpMmGkxlIkpEllDKWcn2iX0Q0DKAa0DWBK0JWhlkUyJZWxkBIpWxkBIJWxkBIJWxkBIJWxkBIpWxkBIJWRkBIJWRYUilZFhSKVkWBIpWJhgk6YUpOmRI7p0wpGZMNJkyUmTJSZMNJjKRJShllnZ9ql3xgFJDQMoBrQNYErQlaGWRTIllbGQEilbGQEglbGQEglbGQEglbGQEilbGQEglZGQEglZFhSKVkWFIpWRYEilYmGCTphSk6ZEjunTCkZkw0mTJSZMlJkw0mMpQlLPT7hLujACSGAUkNAygGtA1gStCVoZZFMiWVsZASKVsZASCVsZASCVsZASCVsZASKVsZASCVkZASCVkWFIpWRYUilZFgSKViYYJOmFKTpkSO6dMKRmTDSZMlJkyUmTDSOJlLPj7pLsjQCTGAEkMApIaBlANaBrAlaErQyyKZEsrYyAkUrYyAkErYyAkErYyAkErYyAkUrYyAkErIyAkErIsKRSsiwpFKyLAkUrEwwSdMKUnTIkd06YUjMmGkyZKTJkpNiSlwJ96l1RlNaTGgEmMAJIYBSQ0DKAa0DW92Ssi3V68LW3nVSeDmko0ovmc5YRx4Y4mc1bVrbTpaP4mQfH3dN1Vnowu5rGtcUaPCKnWfX7lfaxeTbm58t6J6OC93je1aKpcuUV4m/3S+T/AHtX26fpf9v/ADFaK5f6ivE/5SeS/en26fpf9v8AzOtFz/1BeKfyB8j+9Pts/S/7fSdaMn2+vFP5A+b/ALx+2j9L/t9J1o0fb68V/kJ5t+/dT7ZP0+/6TLRu+3l4r/IHzX/l3R+1z9Pv+k60dPt7/i/yE8z/AOXd9afax+n3/SZaPX27/wAb+QPmX/Lu+tPtU/T7/pVV8w68fe7inPhKMqfk1gZbDl6sv531x5TwfSxTv8L4mUMjXNrtrUZRj8dYSp/5Ld14Hl1NDPD0jhevT2jT1fRy49944s0JbErIsCRSsTDBJ0wpSdMiR3TphSMyYaTJkpHElLhWffpdEYASYymtJjQCTGAEkMApIaJY7EsW9iSWLb5kHdLfaRmlo9WEbjKKxbwlC03JcarW9/27ufHcqY3C2zlZ44aHv8PH3WiUqUYRUIRUIRWEYxSjGK5kluFcJXJ3rvZzKUMsoZZQyyhllDLKGWUMsoZZQyyDWOx7jLLlsv5oU6qdW0SpVd7p7qVTo+K/s8p4dfYzLjhwe66Oz7dlj93U4nf9bhZwlCThOLjKLcZRawafMzlZYo7npusIm86JosCUSsTDBJ0wpSdMiR3TphSMyYaTYkpcOz9CS9owZrSYwAkxlNaTGgEmMAJIbR9GebCwWUbiOLfwWDW5bnWfF7l3+VYTdcTlTbH8HB/u8PH3WjmXDuVzpz3t7BujTXoi6W+nGWEKXzkuR/2rF9GOJF3XS2Pk3U1znP3cPj2FneUM+MpV236J7DF/0UIKCX1njL7TW5N3dLk3ZsD0N7+/83d18x5cve37vxyv+oO9670+baH6WP8AieEPTy97fu/Hbj9Rm966+baH6WP+J4U9PL3t+78duP1E3vXZ5tofpY/4nhFZcve37vx24/UTe9dnm2h+lj/ieFZDLl52/d+OV/1BcsuuLs2j+nj/AInhWxy3edvXXjdf9QHLLrYOzaP6eP8AieFbHLd527deN1v1Acsut98HZtH9PH/E8KyOWrvt258arfqA5Zf1Pvi7No/p4+48L6FlnVfUmsLmU18WrhUT6W9veZTW1D13n1Nh0Mvybuzhdpm/npSuXGlcRVCq8FGWPsM5c2L9y+D756dLaTLhlwblbTydlpnOw449/wBbqz1XNuZzyyEq8Hc0o+z01jJJbatNcndLk73Nh49r0Oec49I7737FtPMy5mXovc2fxkchLspWRYEilYmGCTphSk6ZEjunTCkY4ks3XFn6KlvGDNSWwYM1pMYASYymtJje7IWTXeXNC1WKVWaUmt8aaTlN9OqpfYBhr63ktPLPq+Pqt8pU4wjGEIqMIJRjFbFGKWCSNd8iqqvTctpBzkdhRVKhLC6uNZQlv7FTXuqnTtSXF47cGjLo8m7Ia+fOy9A73q8frY43ji2222223i23vbfKwN9SQDWgawJWhK0MsimRLK2MgJFK2MgJBL12VCdepCjSi51KjUYxW9v8t7x5MA81XcWrUyxwxcsncF3dro5lqY1btRqNboUtaEXzYtpy+w3Gy8OLxuLnyub/ALuHD93+fO5zL2Q61hNQq4ShPF06kfczS3rDke7Zx5Tzauk4O5vds+04a+O/Hp9ZdlmFl91ou0rSxqU461Kbe2dNb4vna2dK6D1bNq7/ALj03K5R2UwfKYnB6e363YnruXZZnRk9Wt1UhFYU54Vaa5FGWOzqaku8cXadPmaiHR030OyavlNIXpODfMizzJb0rIsCRSsTDBJ0wpSdMiR3RxDTdcefo04BSYwZqS2DBmtJjACTG7bRNaqV1XrP/wDGioLuqklt70JLrNOp0XO5Vz3aWOPW/D/dqpquDYdnzfu5v7mWOMaUvQ0OEafrWv8APXfWXdfWbBp+T2fA6+Pv+m6+CFL2jQMoBrQNb05PydXupattQqVmtj1IOUYv+6W6PW0Zuhqa2npG/PIO26C30e5TqLF0qdLhUrxx+5rF5jeLLlbZcXpXsPHdNW0d5SisVCjUfxYV1i/81FGODTHlfZV6U7Tw33wco5IurP4TbVKK2LWlHGnjzKaxi31gcUvdpbRpa34eY/H3dN54yNaTS7HRhKPo562GPYKupj8fWhu46uv9o9E+9cnlcfN+HWb+/wCe61o9V8xcnpKcPQcdb3XZqfY+fWwlj93WPPtO7mXS5K3+Wd3Rud/87bPskXztq9Gunh2OcZPuN0l1xcl1ngxebkZXb1tLymnlh1n+rbTr3yVxekih623rcqlOk+OKUl/1ffPBt2PDFuryZlxzx9txMWc1LqpWRYUilZFgSKViYYJOmFKTYk3U3XIH6LZElYBSYwZqS2DBmtJjaFogW2+6LT8Y8+r6rl8qvDT9vytINNx78+ZX+E3P0i485I2br7HR/Dw7D4XkAluGAUkNEscEk220kksW29yS5WHdLfaPmno8TUa+Uk8XhKNqnglxqtb3/auvHcqY3C2zlZ44aHv8PH3WiW9CFKMadKEadOKwjCEVGEVzJLYhXDyyyyXLJ3tYZGhlks4qScZJOLWDTWKa5mZUU4lw2dGj2lVUq2T1GhWW10N1Cpwj8m+jZwWOJry09/RdnY+V88Pu633sev1nj8fhZvRq1rSsmtajcUJ8qwnTqLkaf/xp8qZ50Ru/ljhq4deCe8u7tdJs1DCrZxnUS91Cs4Qk+hxeHfZs8u+suLnyLjzvu6m4/c+pc3l7OCtlCoqlbCMYYqnSjjqQT39LeCxfDkPPqZubxvfs+yYbPjux6fW3ztbY+hmlLfut4tn6yHcx8h1TovjMvSbmNJHwWl9Ih5uoeXbPQO3xuhyX+Ll2fMs9jI5aXaSsiwpFKyLCkUrIsCRSsTDBI4k3UuUP0ONDKxJWAUmMGaktg2h6Id990Wv4x5dc6LmcqdGn7flaMee5N+fcr/CLn5+v5yRv3cC+u0X/AOeHYfC8gEt4wAkhtJ0ZZsrBZRuI4yePoWLXuY7nWfF7UuG3lWE3XE5U2x3+Rwf7vDx+loplw7lM6M+bewcqNNeiblbJU4y1adN8057cHwSb58CLuulsnJmprhk/dw73sLg73SDlKq/WVoW6x3UqMHs5m6mt/wCAOTdrT5K2bHpxcu18N1Xa5/ZTpvF3May+LVoUtX7ii/tJz2WfJWy5HDDd2L8992ubekOhdSjRu4K2rSajGetjbzlzYvbB8Hs4iM99yNq5Iz0hy03nY9/1/nC7YdyLjNIubKuqTu6EPbVCOMkltrUVtceMlta61yrDXnjv43W5L23yWfks37j3Ph1++yaEzzJfTpXRkBIJWa2x9DAkd3G32197h3EfIjpHRfE5+k3L6S37VpfSIebqHm2v0Dt8bo8lfi5dnzLOoyOal3ErIyAkErIsKRSsiwpFKyLAkUm1ibo7rlkfoVqiStDKxJWAUmNoWiLffdFr+MeLaToudyk8MPb8rRjy3Lvz9lf4Rc/P1/OSPVu4F9Zov/zx7D4XjAluG9mR7B3dxQtls7NUjBtb1DfKS4qKk+oDHV1fJaeWfUf677fqNKNOMYQiowhFQjFboxSwSXUa75BVVem5XSHnHKxoRpUJatzcayjJb6VJe6qdO1JdOPIZdHk3ZDW1Odl6B3vqPH62Ovvt7W3tbfOBvqSAa0DWDJK1LRhnJKvF2FxJyqUo69CbeMpUVgnBvlccVhwfA24Pqvm+V9jMHy2Bwent6/b8e278dxLCs88lqyvq9GKwpSar0lyKnPbguClrxXcnnzx3N9nsGv5fZ8cnp6HtPpub5MZGpL1JWOWx9DAkd3G/QVp73T7iHkR7zovhs/SbldJz9qUvpMPNVTz7V6B23S5J/Gy7PmWbxkc9LvJWxkBIJWRkBIJWRYUilZFhSKTawd0d1zJ+gXnijKxJWhlYkraFoi333Ra/jHi2s9H2/K5/KHRh7flaKeO5t+f8rfCLn5+v5yR7Q4F9Tov3Mew+F5Apbhus0X0VPKGLXvVCtUXB4wh5Js05nC8XKeW7Z+1D4tr5qvnbFdIl262Ua6fuaKp0IdyoqT+9OZd3C+p5NwMNnx/fe/z2XNBS6A0DKAa0DW+lmzdu3vbSrHkr04vuJvUl92UjDg2ja9M1NDUxep7uJ32/G++Jsv0w0Uq1nUw2zp14N8ISg15xmrUL6PkPL7mpj1J37/Cz9M1Jdydy2PoYEpu436ItPe6fcQ8iPYdF8Hn6TcnpRftSj9Jh5qqaNp9E7bp8kfjZf2/Ms0jI8KXfStjICRStjICQSsjICQSsiwpFJtYm6m65w+9vFEyUUZWJK0MraHoj33vRa/jHi2z8vt+Vz9v/ACe35WiniudYBlb4RcfP1/OSOiH3S+m0n7mPYfC8jAluG6/RXPVv5J/1W1WK6dek/JFmnVOF4uUuOgdp8G1s89wLEc/aDp5Ruk1slKFSL54ypxeK68V1DOi+p2DIdnw/nrufCl7hgFJDQMoBre3IdB1bq1pxWLlXoLoWum31LF9RA42raMzHRzXqfhfoM3XxFmWmKeNSxjyxhdSfQ3SS/wCrNepfRchH3dV/t+dnZqu7CTwT6GTdU6b9G2nvdPuIeRHpL4HP0m5HSo/adH6TDzVU06/o3U5H/Gy/t+ZZjGR40voUrYyAkErYyAkUrYyAkErIyAkEm1ibqbrnz7y50SSiZKKMrElbQ9EW+96LX8Y8W2fl9vyvBt/5Pb8rRTxXOsByt8IuPn6/nJHVxPunZfRaT9zHsLyMCW8b6WbOUFaXlvcSeEIT1ajx2KnJOEm+hSb6jVnjvEte0YeU0ssTpt3PFfNXAaU8hOpCF/SjjKjHsddLf2DHFT+q28eEseQeL6rr8l7RzcnSfX0dv1sxKl3hgBJDAKSGgZXe6LMhOpVeUKkfY6WtToY/11mtWU1wim10yfMZiXG5X2oxw8ji8Xi9nq9/T/u1Id87YppGykrnKFVReMLeMbZbdjlFtzfTrSlH6ppzeN9dyXo+T2bHf0vH39Hdx9tzILoy1Nz6GZLHpL9G2nvdPuIeRHpL4DP0m5DSw/adH6VDzVU1a3o3V5F/Hy/t+ZZdGR5Evo0rYyAkErYyAkErYyAkUrYyAkEm1g7o7r4SPurlxMrEkomSijK2iaIt990Wv4x4ts/L7fleDb/ye35WinhufYFlb4RcfP1/OSOvh6J2F39P0MewvIYluGDRqS2Da1o7zhV1QVrVl7ZtoqO17alBbIz4tbE+p8p4tXDmu/1XF27Z+Znzz0X4/wA6Lrmk9jWKexp7mjVeCzjOfR08ZVsnYYPGTtZNRSf+1J7Ev7Xglz7kMy67tbLyn+XW9/j43C3mS7mg2q1tVptbMZUpKPVLDB9TLdbDW08/RyH21dtYV6zwpUKtVvZ6ylOfkQG2ZauGPpZB2t2WbmjmtVaqZQ9hpLb2GMk61ThJrZBdDb6N4d1zdp5WwxN2jxy6/V9fh22oW9CFKEadOChTglGEIrCMYrcki3z+WTkuWTvW+HnpnDHJ1u5Ra9E1cYW8N/r8Ns2vixxx7y5SLuvXsGyO0am59A6fDtfrYe23tbbb2tt4tvnb5Wam+wIBrLU3PoZksekv0bae90+4h5Eegvgc/SbjtLj9pUPpVPzNY16nRdfkT8fL+1+JZXGR5kvpErYyAkErYyAkErYyAkErYyAkUn1g7o7r4iPuLjDMiSiZWJJRMlaJoh333Ra/jHi2z8vt+V4du/L7flaMeG59gWVvhFx8/X85I7GHonYXe0/Qx7C8pbZAKTGusrupb1IVqM3CrTetGS5HzcU9zXKassRNzLLHHPFxyN5a1mrnlQv1GlUaoXe5028IVXz029/c71x3niz0nHsuJtOx5aXE44/zpuoNV46GWUMsoZZfBzmzqtsnRam+yXDWMLeDWu+Zy+LHi+rHcZezZdi1NoeHDHr/AJ0tjmWcq1r6tK4uJYzlsSWyFOHJCK5Ev/YG+p0NHDRwMMDh8bwBt9A1kqbn0Mksekv0dae90+4h5Eegvgs/SbjNLvwKh9Lh5msDU6Lr8h/j5/2/MsnTNCX01bGQEilbGQEglbGQEglbGQEgk+sHdTdfITPtrgjFEkMyJKJlYkld3oluVG4uaPLUpQqL6ksPxDybYfdG8m2m/HFtQOfc6wzOu0dC+u6b+WnUXc1Hrr7JYdR1tHLnYYt29DLnaeL+3wvlGy3RJWAUmMGjUlsG6HJOet/apRVVV6a3QrpzaXCWKl320aMtLFvPqbFo6nHduf2/m66K30ofK2PXCvjj1OKw75qdL97yvJX9Ofd9Zq+lGKXsdi2/77hRS70WHydceSX82fd9bn8q5/X9wnGE420HswoxfZGuM5YvrjgTm3t0eTdDDinOf36Pd477lpycm5SblKTbcm25SfO297Cl0ThwOiUKTGgZQDWttLV3FSnQj7qtOFFYcjlJRx+0m6meoaeLm+o3+6/RUVgkluWxdBuvhLPtMFylStKH9UqtSthwhDV/ENepd3kPB5+pn6twe93/ACswNV9FFMiWVsZASKVsZASCVsZASCT6wd1N18s+zvmxmTMmMUSQzIkomVvq5sZT9BXdC4bwhGWrU+aktWT6k8epGvVw5+CeuOrhz8Et2Tx2rantT5MDj3HuE0nZBdWEb+lHGVGOpXS3uji2p/VbePB8D2bLq7nmN7tj1tzzH19FmZ7rpUMrElYBSYwZqS2DBmtJjACTGU1pMaASYwAkhgFJDQMrvtF2b7qVPTGrHCnS1oW+P9dV4xlNcIrFdLfxTMS43K+1mOPkcXi9PZ6j29P+7UR3ztimkTKqu76ooPGlbL0NHbscotub/wAm19VGnN3t9dyXoeS2c39OXHw7uPtuZBdGhlkUyJZWxkBIpWxkBIJPrB3R3Xz0z7G+WGJJjMmZMYokhmRJRMrapo2zkVemrGtL2ejHCk2/faC5O6ju6MHyM521aXNecdDeDatLc886G7ho8l5LO86NHzblXyckscXK1bUVj/tN7F3LwXM1sR7dLavVn77oaO2erU9/jcDeWlW3lqV6U6MuapBxb6Md/Sj2Y5GXQ77345GXHF31OJZUxM3VpiBJjKzWlsGGJqSYwxAkyGJrSZDECTJ7ejOrLUpQlVn8SnCU596O0KVcjE35O4/fhdxmzo7q1XGrlD2GitvYFL2apwk17hdDx7kG65W1crY4nN0eOXX6vr8O21ChRjTjGnTioQglGMIpKMYpYJJLci3z+WTkqu9bms/M5Vk+g4Upe266caSW+nHc6z6OTnfQ8It0OTtj8vqb8vQOn9/28f2sXNV9ZANaErQyyKZEsrYyAkUn1g7o7rxo+vvkRimSQxJMZkzJjFEkMyJKsoVpU5RqU5OE4NSjOLwlGS3NEQTc14JubVs0s+qV0o0Ltxo3OyKm8I0az4P+mXB7+TmXO1tmceOPEufrbM48ceJdmeW8ss4KSwklJPkaTRll5Xkq27Wo+Bp/kLn5dcufl1tPSq27Vo+Ap/kZz8uuvlMutp6VW3atHwNP8jOfl12eUz/qaelVt2rR8BT/ACM5z12eUz/qffT0ptu1aPgKf5E5z12eVz/qffT0pte1aPgKf5Gb2vlc/wCp99PSm17Vo+Ap/kZvs8rqf1Pvp6U2vatHwFP8iWeW1P6n33ppUowWEIxguaMUl9hkFXpZzKXL51550MnqVODVe73KlF+tpvnqNbu53vhvMuhsfJ+eu854YdfX2fzdZBlC+q3VWdevNzqzeMpP7ElyJcwG+o0tPHTxMMDcF5g2ygawJWhK0MsimRLJtYm6m686Z9ZfGDMiSGKZJDEkxmTMmMUSQzIkomVG+9kXO69skoU63ZKS2KlWTqQS5ovHWXQnhwNOehhn0nG156GGfScf2uss9J8H7/Zyi+elVjPHqklh32ebLY31ZXndifVle1aS7L5C6/wo/uB8zz6z+eyPmWfWd/hH1S7L5C68HR/cJ5pn1n89lnmOp1nf4U9Uqy+QuvB0f3DPNM+s/nsr5jqdZ3+FPVKsvkLrwdH9wzzTPrP57LPMdTrO/wAKeqVZfIXXg6P7hPNc+sr5hqdZ3+EPVLsvkLrwdH9wnm2XWV+ztTrO/wAKeqZZfIXXg6P7gfIZdcvs3V/qO/wh6pll8hdeDo/uE8k1+y9X+o7/AAvLdaUKSXsFnUk/92pCmvu6xPJ23DknLf8AezPZx8Ll8sZ8390nBVFb03s1aCcZNcZt63ewJzboaHJ+hp8d3Of38P8AdzIUugMApIaBlANaBrAlaErQyyhlahM+rvhxmTJMZkSQxTJIYkmMyZkxiiSGZElEysSSiZKKMrElaGViSsApMYM1JbBgzWkxgBJjKa0mNAJMYASQwCkhoGUA1oGsCVoStDLLzpn1l8KMUyTGZMkxmRJDFMkhiSYzJmTGKJIZkSUTKxJKJkooysSVoZWJKwCkxgzUlsGDNaTGAEmMprSY0AkxgBJDAKSGgZQDWgawJWhlbypn1d8EMyZkximSYzJkmMyJIYpkkMSTGZMyYxRJDMiSiZWJJRMlFGViStDKxJWAUmMGaktgwZrSYwAkxlNaTGgEmMAJIYBSQ0DKAa0DWBlbxpn1d8CMyZJDMmZMYpkmMyZJjMiSGKZJDEkxmTMmMUSQzIkomViSUTJRRlYkrQysSVgFJjBmpLYMGa0mMAJMZTWkxoBJjACSGAUkNAygGtCVvAmfV35+MyZJjMmSQzJmTGKZJjMmSYzIkhimSQxJMZkzJjFEkMyJKJlYklEyUUZWJK0MrElYBSYwZqS2DBmtJjACTGU1pMaASYwAkhgFJDQMqErfOR9TfnxMjJkyJMmRJkUSZMiSJkSZFGSJiTIkkTIyZFEkRRKxMlEkooysyJKhlYmWUIyIGtmSs1tsIM1syDNbMgwMyAGZQDIgFlQlb//Z" alt="Instagram" style="width: 20px; height: auto;" />
        </a><br>
    </div>
    
</div>
';
    // $mail->AltBody = 'This is the body in plain text for non-HTML mail clients';

   if( $mail->send()){
    echo 'Message has been sent';
   ?> 
   <form action="create.php" method="post">
    <div class="container ">
        <div><b>
            <label>يرجى التحقق من الايميل الخاص بك وادخال الرمز التحقق الخاص بك </label>
                     </b><br>   
                                </div>
                                <div class="input">
                                    <label for="code"> OTP CODE :</label>
                                    <input type="tel" maxlength="1" class="input-code" name="code1" id="code">
                                    <input type="tel" maxlength="1" class="input-code" name="code2" id="code">
                                    <input type="tel" maxlength="1" class="input-code" name="code3" id="code">
                                    <input type="tel" maxlength="1" class="input-code" name="code4" id="code">
                                    
                                </div>






   </div>
   </form>


 <?php

}else{
    echo"ERROR";
}}
}