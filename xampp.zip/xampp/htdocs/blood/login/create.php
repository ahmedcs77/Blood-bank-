<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
    include("../auth/db_connect.php");
    session_start();
    $q="select * from users where email='".$_POST['email']."'";
    $result=mysqli_query($conn,$q);
    $rows=mysqli_num_rows($result);
    if($rows>0)
    {
        $_SESSION['error']="الايميل موجود مسبقا";
        header("Location:../create_account.php");
    }
    else
    {
    if(isset($_POST["signup"]))
    {
        
function generateRandom4Digit() {
    return rand(1000, 9999);
}

$randomNumber = generateRandom4Digit();
$_SESSION['Random'] = $randomNumber;
// echo"ok";exit();
            $to = $_POST['email'];
          $subject = "كود التاكد من البريد الالكترني" ;
          $email_message = "كود التحقق هو : " . $randomNumber . "\r\n يرجى ادخال الرقم في الصفحة";
          $headers = "From: blood00bank@gmail.com\r\n";
          
          if (mail($to, $subject, $email_message, $headers)) {
              $_SESSION['success']="تم ارسال البريد شكرا لكم";
              $_SESSION['name']=$_POST['name'];
            $_SESSION['email']=$_POST['email'];
            $_SESSION['password']=$_POST['password'];
              header('location:ver.php');
          } else {
             $_SESSION['error']="فشلت العملية";
          }
          
        // include("../auth/islogin.php");
        // include("../auth/db_connect.php");
        
       
    }
    }
?>
</body>
</html>