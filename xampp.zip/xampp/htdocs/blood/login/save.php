<?php
include '../auth/db_connect.php';
session_start();
if($_POST['Rand']==$_SESSION['Random'])
{
    $query="insert into users (username,email,password,verify) values ('".$_SESSION['name']."',
    '".$_SESSION['email']."','".$_SESSION['password']."','".$_SESSION['Random']."')";
    // echo $query;exit();

    $result=mysqli_query($conn,$query);
    mysqli_close($conn);
    $_SESSION['success']="تم انشاء الحساب يرجى اختيار خدمة من خدماتنا";
    header("Location:../index.php");
   
}
else
{
    $_SESSION['error']="الارقام غير متطابقة";
    header("Location:../create_account.php");

}

?>