CREATE TABLE `doctor` (
  `do_id` int(30) NOT NULL,
  `name` varchar(50) NOT NULL,
  `phone` varchar(50) NOT NULL,
  `address` varchar(100) NOT NULL,
  `email` varchar(50) NOT NULL,
  `l_id` int(30) DEFAULT NULL,
  `date_created` datetime NOT NULL DEFAULT current_timestamp(),
  `check` tinyint(4) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE `donate_for_patient` (
  `id` int(30) NOT NULL,
  `d_id` int(30) NOT NULL,
  `p_id` int(30) DEFAULT NULL,
  `l_id` int(30) DEFAULT NULL,
  `date_created` datetime NOT NULL DEFAULT current_timestamp(),
  `check` tinyint(4) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE `donation` (
  `id` int(30) NOT NULL,
  `d_id` int(30) DEFAULT NULL,
  `do_id` int(30) DEFAULT NULL,
  `check` tinyint(4) DEFAULT 0,
  `date_created` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE `donors` (
  `d_id` int(30) NOT NULL,
  `firste_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `med_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `last_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `age` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `address` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `phon` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `blood_group` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `date_created` datetime NOT NULL DEFAULT current_timestamp(),
  `Date_after_6Months` datetime GENERATED ALWAYS AS (`date_created` + interval 6 month) VIRTUAL,
  `DAY_Count` int(11) GENERATED ALWAYS AS (to_days(curdate()) - to_days(`date_created`)) VIRTUAL,
  `status` tinyint(4) NOT NULL DEFAULT 0,
  `Remaining_days` int(11) GENERATED ALWAYS AS (to_days(`Date_after_6Months`) - to_days(curdate())) VIRTUAL,
  `i` int(10) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
CREATE TABLE `floor` (
  `f_id` int(30) NOT NULL,
  `f_num` int(30) DEFAULT NULL,
  `date_created` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE `hospitals` (
  `h_id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `city` varchar(100) NOT NULL,
  `floor` int(30) NOT NULL,
  `address` varchar(100) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `date_created` datetime NOT NULL DEFAULT current_timestamp(),
  `check` tinyint(4) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE `laboratory` (
  `l_id` int(30) NOT NULL,
  `name` varchar(50) NOT NULL,
  `h_id` int(11) DEFAULT NULL,
  `f_id` int(30) DEFAULT NULL,
  `date_created` datetime NOT NULL DEFAULT current_timestamp(),
  `check` tinyint(4) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE `patient` (
  `p_id` int(30) NOT NULL,
  `firste_name` varchar(50) NOT NULL,
  `med_name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `phone` varchar(50) NOT NULL,
  `blood_group` varchar(10) NOT NULL,
  `address` varchar(100) NOT NULL,
  `date_created` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
CREATE TABLE `request` (
  `id` int(30) NOT NULL,
  `p_id` int(30) DEFAULT NULL,
  `do_id` int(30) DEFAULT NULL,
  `check` tinyint(4) DEFAULT 0,
  `timeattendance` datetime NOT NULL DEFAULT current_timestamp(),
  `date_created` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE `users` (
  `id` int(30) NOT NULL,
  `username` varchar(200) NOT NULL,
  `email` varchar(200) NOT NULL,
  `password` text NOT NULL,
  `type` tinyint(10) DEFAULT 1,
  `verify` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
ALTER TABLE `doctor`
  ADD PRIMARY KEY (`do_id`),
  ADD KEY `fk_doctor1` (`l_id`);ALTER TABLE `donate_for_patient`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `d_id` (`d_id`),
  ADD UNIQUE KEY `p_id` (`p_id`),
  ADD KEY `fk_donate_for_patient` (`d_id`),
  ADD KEY `fk_donate_for_patient1` (`l_id`),
  ADD KEY `fk_donate_for_patient2` (`p_id`);ALTER TABLE `donation`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_donation` (`d_id`),
  ADD KEY `fk_donation1` (`do_id`);ALTER TABLE `donors`
  ADD PRIMARY KEY (`d_id`);
  ALTER TABLE `floor`
  ADD PRIMARY KEY (`f_id`);ALTER TABLE `hospitals`
  ADD PRIMARY KEY (`h_id`),
  ADD KEY `fk_hos` (`floor`);ALTER TABLE `laboratory`
  ADD PRIMARY KEY (`l_id`),
  ADD KEY `fk_laboratory` (`h_id`),
  ADD KEY `fk_laboratory1` (`f_id`);ALTER TABLE `patient`
  ADD PRIMARY KEY (`p_id`);ALTER TABLE `request`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_request` (`p_id`),
  ADD KEY `fk_request1` (`do_id`);ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`);

INSERT INTO `floor` (`f_id`, `f_num`, `date_created`) VALUES
(1, 1, '2024-03-19 18:32:10'),
(2, 2, '2024-03-19 18:32:10'),
(3, 3, '2024-03-19 18:32:10'),
(4, 4, '2024-03-19 18:32:10'),
(5, 5, '2024-03-19 18:32:10'),
(6, 6, '2024-03-19 18:32:10'),
(7, 7, '2024-03-19 18:32:10'),
(8, 8, '2024-03-19 18:32:10'),
(9, 9, '2024-03-19 18:32:10'),
(10, 10, '2024-03-19 18:32:10');
ALTER TABLE `doctor`
  MODIFY `do_id` int(30) NOT NULL AUTO_INCREMENT;
ALTER TABLE `donate_for_patient`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT;
ALTER TABLE `donation`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT;
ALTER TABLE `donors`
  MODIFY `d_id` int(30) NOT NULL AUTO_INCREMENT;
ALTER TABLE `floor`
  MODIFY `f_id` int(30) NOT NULL AUTO_INCREMENT;
  ALTER TABLE `hospitals`
  MODIFY `h_id` int(11) NOT NULL AUTO_INCREMENT;
  ALTER TABLE `laboratory`
  MODIFY `l_id` int(30) NOT NULL AUTO_INCREMENT;
  ALTER TABLE `patient`
  MODIFY `p_id` int(30) NOT NULL AUTO_INCREMENT;
  ALTER TABLE `request`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT;
  ALTER TABLE `users`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT;
  ALTER TABLE `doctor`
  ADD CONSTRAINT `fk_doctor1` FOREIGN KEY (`l_id`) REFERENCES `laboratory` (`l_id`);

ALTER TABLE `donate_for_patient`
  ADD CONSTRAINT `fk_donate_for_patient` FOREIGN KEY (`d_id`) REFERENCES `donors` (`d_id`),
  ADD CONSTRAINT `fk_donate_for_patient1` FOREIGN KEY (`l_id`) REFERENCES `laboratory` (`l_id`),
  ADD CONSTRAINT `fk_donate_for_patient2` FOREIGN KEY (`p_id`) REFERENCES `patient` (`p_id`);

ALTER TABLE `donation`
  ADD CONSTRAINT `fk_donation` FOREIGN KEY (`d_id`) REFERENCES `donors` (`d_id`),
  ADD CONSTRAINT `fk_donation1` FOREIGN KEY (`do_id`) REFERENCES `doctor` (`do_id`);

ALTER TABLE `hospitals`
  ADD CONSTRAINT `fk_hos` FOREIGN KEY (`floor`) REFERENCES `floor` (`f_id`);

ALTER TABLE `laboratory`
  ADD CONSTRAINT `fk_laboratory` FOREIGN KEY (`h_id`) REFERENCES `hospitals` (`h_id`),
  ADD CONSTRAINT `fk_laboratory1` FOREIGN KEY (`f_id`) REFERENCES `floor` (`f_id`);

ALTER TABLE `request`
  ADD CONSTRAINT `fk_request` FOREIGN KEY (`p_id`) REFERENCES `patient` (`p_id`),
  ADD CONSTRAINT `fk_request1` FOREIGN KEY (`do_id`) REFERENCES `doctor` (`do_id`);
COMMIT;