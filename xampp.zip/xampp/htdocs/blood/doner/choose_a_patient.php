<?php
if($_GET['id'])
{
 session_start();
 $_SESSION['donation_id']=$_GET['id'];
 header('location:../admin/add_doner.php');
 // echo "hello";exit();

}
?>