<?php
session_start();
// echo "this is a patient choose";
if(isset($_SESSION['donation_id']))
{
$donation_id=$_SESSION['donation_id'];
unset($_SESSION['donation_id']);
if(isset($_POST))
{

    
  function canDonateBlood($donorBloodType, $recipientBloodType) {
    // Define the allowable blood type combinations
    $allowableBloodTypes = array(
        1 => array(1, 7),
        2 => array(1, 2, 7, 8),
        3 => array(3, 7),
        4 => array(3, 4, 7, 8),
        7 => array(7),
        8 => array(7, 8),
        5 => array(1, 3, 7, 5),
        6 => array(1, 2, 3, 4, 7, 8, 5, 6)
    );

    // Check if the donor's blood type is in the allowable types for the recipient
    if (isset($allowableBloodTypes[$recipientBloodType]) && in_array($donorBloodType, $allowableBloodTypes[$recipientBloodType])) {
      //  echo 'TRUE';exit();
      return true;
    }
    // echo 'FALSE';exit();

    return false;
}



 include '../auth/db_connect.php';
 $sql = "SELECT r.id,do.do_id,do.name,p.p_id,p.firste_name,p.med_name,p.last_name,p.blood_group,l.l_id,l.name,h.name,h.city,h.address
 FROM request r, doctor do , patient p, laboratory l, hospitals h 
 where r.p_id=p.p_id and r.do_id=do.do_id and do.l_id=l.l_id and l.h_id=h.h_id and r.check='0' and r.id=".$donation_id."";
// echo $sql;exit();  
$result=mysqli_query($conn, $sql);
$rows=mysqli_fetch_row($result);
$blood_type=$rows[7];
$candon=canDonateBlood( $_POST['blood_group'],$blood_type);
// echo $candon;exit();  

if($candon){
 // $_SESSION['success']='فصائل الدم متضابقة';
 // we need here
// code for checking that this user did not request befor

 // 
    
 $query="insert into donors (`firste_name`, `med_name`, `last_name`, `age`, `address`, `phon`, `blood_group`)
 values ('".$_POST['first_name']."','".$_POST['med_name']."','".$_POST['last_name']."',
 '".$_POST['age']."','".$_POST['address']."','".$_POST['phone']."',".$_POST['blood_group'].")";
// echo $query;exit();
$result=mysqli_query($conn,$query);
$don_id="select * from donors where firste_name='".$_POST['first_name']."' and med_name='".$_POST['med_name']."' and last_name='".$_POST['last_name']."' ";
    $result=mysqli_query($conn,$don_id);
    $don_id= mysqli_fetch_row($result);
    //

    //  echo $query;exit(); 
     $result=mysqli_query($conn,$query1);
    $query1="insert into donate_for_patient (d_id,p_id,l_id)
     values (".$don_id[0].",".$rows[3].",".$rows[8].")";
    //  echo $query;exit(); 
     $result=mysqli_query($conn,$query1);
     // update the donation table change the check in to 1 which means this user is un avalable
     $query="UPDATE `request` SET `check`='1' WHERE id =".$donation_id;
     // echo $query;exit(); 
     $result=mysqli_query($conn,$query);
    mysqli_close($conn);
    $_SESSION['success']="     تمت اضافة 'طلبك'";
    header("Location:../admin/bloodtypes/fordoner.php");
   
}
else
{
 $_SESSION['error']='لا يمكنك التبرع لفصيلة الدم هذة اختر فصيلة مطابقة';
 header("Location:../admin/bloodtypes/fordoner.php");
}
echo $blood_type;
 ?>
 <input type="text" name="fn" value="<?php echo $_POST['first_name'];?>">
 <input type="text" name="mn" value="<?php echo $_POST['med_name'];?>">
 <input type="text" name="ln" value="<?php echo $_POST['last_name'];?>">
 <input type="text" name="ad" value="<?php echo $_POST['Address'];?>">
 <input type="text" name="phone" value="<?php echo $_POST['phone'];?>">
 <input type="text" name="bg" value="<?php echo $_POST['blood_group'];?>">
 <?php
}
}
else
{
 header('location:../404.html');
}

?>