<?php
session_start();
// echo "this is a patient choose";
if(isset($_SESSION['donation_id']))
{
$donation_id=$_SESSION['donation_id'];
unset($_SESSION['donation_id']);
if(isset($_POST))
{

  function canDonateBlood($donorBloodType, $recipientBloodType) {
    // Define the allowable blood type combinations
    $allowableBloodTypes = array(
        1 => array(1, 7),
        2 => array(1, 2, 7, 8),
        3 => array(3, 7),
        4 => array(3, 4, 7, 8),
        7 => array(7),
        8 => array(7, 8),
        5 => array(1, 3, 7, 5),
        6 => array(1, 2, 3, 4, 7, 8, 5, 6)
    );

    // Check if the donor's blood type is in the allowable types for the recipient
    if (isset($allowableBloodTypes[$recipientBloodType]) && in_array($donorBloodType, $allowableBloodTypes[$recipientBloodType])) {
      //  echo 'TRUE';exit();
      return true;
    }
    // echo 'FALSE';exit();

    return false;
}


 include '../auth/db_connect.php';
 $sql = "SELECT don.id,do.name,d.d_id,d.firste_name,d.med_name,d.last_name,d.blood_group,h.name,h.city,h.address,l.l_id,l.name
 FROM donation don, doctor do , donors d, laboratory l, hospitals h 
 where don.d_id=d.d_id and don.do_id=do.do_id and 
  do.l_id=l.l_id and l.h_id=h.h_id and don.id=".$donation_id." and don.check='0'";
// echo $sql;exit();  
$result=mysqli_query($conn, $sql);
$rows=mysqli_fetch_row($result);
$blood_type=$rows[6];
$candon=canDonateBlood($blood_type, $_POST['blood_group']);
// echo $candon;exit();  

if($candon)
{
 // $_SESSION['success']='فصائل الدم متضابقة';
 // we need here
// code for checking that this user did not request befor

 // 
    // echo "CAN DON";exit();  

 $query="insert into patient (firste_name,med_name,last_name,phone,blood_group,address)
 values ('".$_POST['first_name']."','".$_POST['med_name']."','".$_POST['last_name']."',
 '".$_POST['phone']."',".$_POST['blood_group'].",'".$_POST['Address']."')";
// echo $query;exit();
$result=mysqli_query($conn,$query);
$pat_id="select * from patient where firste_name='".$_POST['first_name']."' and med_name='".$_POST['med_name']."' and last_name='".$_POST['last_name']."' ";
    $result=mysqli_query($conn,$pat_id);
    $pat_id= mysqli_fetch_row($result);
    $query="insert into donate_for_patient (d_id,p_id,l_id)
     values (".$rows[2].",".$pat_id[0].",".$rows[10].")";
    //  echo $query;exit(); 
     $result=mysqli_query($conn,$query);
     // update the donation table change the check in to 1 which means this user is un avalable
     $query="UPDATE `donation` SET `check`='1' WHERE id =".$donation_id;
     // echo $query;exit(); 
     $result=mysqli_query($conn,$query);
    mysqli_close($conn);
    $_SESSION['success']="     تمت اضافة 'طلبك'";
    header("Location:../admin/bloodtypes/forpatient.php");
   
}
else
{
  // echo "CAN NOT DON";exit();  

 $_SESSION['error']='لا يمكن لفصيلة دمك الحصول على فصيلة الدم هذة اختر فصيلة مطابقة';
 header("Location:../admin/bloodtypes/forpatient.php");
}
echo $blood_type;
 ?>
 <input type="text" name="fn" value="<?php echo $_POST['first_name'];?>">
 <input type="text" name="mn" value="<?php echo $_POST['med_name'];?>">
 <input type="text" name="ln" value="<?php echo $_POST['last_name'];?>">
 <input type="text" name="ad" value="<?php echo $_POST['Address'];?>">
 <input type="text" name="phone" value="<?php echo $_POST['phone'];?>">
 <input type="text" name="bg" value="<?php echo $_POST['blood_group'];?>">
 <?php
}
}
else
{
 header('location:../404.html');
}

?>