<?php
if($_GET['id'])
{
 session_start();
 $_SESSION['donation_id']=$_GET['id'];
 header('location:add_patien.php');
 // echo $id;exit();

}


?>