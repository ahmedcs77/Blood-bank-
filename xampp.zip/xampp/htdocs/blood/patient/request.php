<?php
session_start();
 if(isset($_POST["sigin"]))
{
    // echo"hhhh";exit();
 
    include("../auth/db_connect.php");
    $first_name=$_POST['fn'];
    $med_name=$_POST['mn'];
    $last_name=$_POST['ln'];
    $address=$_POST['ad'];
    $phone=$_POST['phone'];
    $blood_group=$_POST['bg'];
    $hos=$_POST['hos_id'];
    $doc=$_POST['doc_id'];
    
    $query="insert into patient (firste_name,med_name,last_name,phone,blood_group,address)
     values ('".$first_name."','".$med_name."','".$last_name."','".$phone."','".$blood_group."',
     '".$address."')";
    // echo $query;exit();
    $result=mysqli_query($conn,$query);
    // echo $query;exit();
    $pat_id="select * from patient where firste_name='".$first_name."' and med_name='".$med_name."' and last_name='".$last_name."' ";
    $result=mysqli_query($conn,$pat_id);
    $pat_id= mysqli_fetch_row($result);
    $query="insert into request (p_id,do_id)
     values (".$pat_id[0].",".$doc.")";
    //  echo $query;exit(); 
     $result=mysqli_query($conn,$query);
    mysqli_close($conn);
    $_SESSION['success']=" تمت اضافة 'طلبك'";
    header("Location:../admin/bloodtypes/forpatient.php");
}

?>