function countdown(minutes, seconds) {
    let totalSeconds = minutes * 60 + seconds;

    let timer = setInterval(function () {
        let minutesLeft = Math.floor(totalSeconds / 60);
        let secondsLeft = totalSeconds % 60;

        let minutesDisplay = minutesLeft < 10 ? '0' + minutesLeft : minutesLeft;
        let secondsDisplay = secondsLeft < 10 ? '0' + secondsLeft : secondsLeft;

        document.getElementById('timer').innerText = `الوقت المتبقي للادخال: ${minutesDisplay}:${secondsDisplay}`;

        if (totalSeconds <= 30) {
            document.getElementById('timer').style.color = 'red';
            // document.getElementById('timer').background.color = '#fff';
        }

        if (totalSeconds <= 0) {
            clearInterval(timer);
            document.getElementById('otp-input').disabled = true;
            document.getElementById('verify-btn').disabled = true;
         
	setTimeout(() => {
		alert('Please enter .tow again');
	}, 1000);

        } else {
            totalSeconds--;
        }
    }, 1000);
}


function sendOTP() {
    // Function to verify the OTP
    // let input=document.textContent;
  document.getElementById("redirect-form-send").submit();

    // alert('Verifying OTP ');
}

countdown(2, 0);
