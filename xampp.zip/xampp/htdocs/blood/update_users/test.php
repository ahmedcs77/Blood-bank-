<?php
session_start();
echo"<br>This is echo Cookise<br>";
    echo"Tihs is Cookise<br><pre> ";
    print_r($_COOKIE);
echo"</pre><hr>";
echo"Tihs is SESSION<br><pre> ";
    print_r($_SESSION);
echo"</pre><hr>";

    echo"Yes IN THE POST POST<br>";
    echo"Tihs is POST<br><pre> ";
    print_r($_POST);
echo"</pre><hr>";

?>