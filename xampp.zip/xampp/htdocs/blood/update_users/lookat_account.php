<?php 
session_start();
// print_r($_REQUEST);exit();
if(isset ($_POST['lookfor'])){
    include ('../auth/db_connect.php');
    $sql = "SELECT * FROM `users` WHERE  `email` ='".$_POST['email']."';";
    // echo $sql; exit();
    $result = mysqli_query($conn, $sql);
    $row = mysqli_num_rows($result);
    if($row>0 ){    
       
    function generateRandom4Digit() {
        return rand(1000, 9999);
    }
    

    $randomNumber = generateRandom4Digit();
    $_SESSION['Random'] = $randomNumber;
    // echo"ok";exit();
    $row=mysqli_fetch_row($result);
            $to = $_POST['email'];
              $subject = "اعادة تعبن كلمة السر";
              $email_message = "كود التحقق هو : " . $randomNumber . " يرجى ادخال الرقم في الصفحة";
              $headers = "From: blood00bank@gmail.com";
              
              if (mail($to, $subject, $email_message, $headers)) {
                  $_SESSION['success']="تم ارسال البريد شكرا لكم";
                        $_SESSION['id']=$row[0];
                      $_SESSION['name']=$row[1];
                    $_SESSION['email']=$row[2];

                $_SESSION['success']="تم ارسال البريد ";
                  header('location:newpassword.php');
              } else {

                 $_SESSION['error']="فشلت العملية";
                 header("Location:../create_account.php"); exit();             
              }

            

    

}else{ 
    $_SESSION['error']="البريد الالكتروني غير موجود";
    header("Location:../create_account.php"); exit();
}

}else{
    header("Location:../create_account.php"); exit();
}
?>