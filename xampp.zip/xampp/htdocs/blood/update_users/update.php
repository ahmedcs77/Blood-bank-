<?php
session_start();
$newpassword =$_POST['newpass'];
$rand=$_POST['Rand'];

if($rand==$_SESSION['Random'])
{
    include('../auth/db_connect.php');
    $q="update users set password='".$newpassword."' where id=".$_SESSION['id'];
    // echo $q;exit();
    mysqli_query($conn,$q);
    $_SESSION['success']="تم تغير كلمة المرور";
    header('Location:../index.php');
}


