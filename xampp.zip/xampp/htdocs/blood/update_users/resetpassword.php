<?php
session_start();
if(isset($_SESSION['username'])&& isset($_SESSION['id'])&&isset($_SESSION['type']))
{
    // echo" destroy<hr>";
  session_unset();
  session_destroy();
  sleep(1);

}


?>
 
 
<!DOCTYPE html>
<html lang="ar" dir="rtl">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>blood</title>

    <!--====== Favicon Icon ======-->
    <link
      rel="shortcut icon"
      href="../assets/images/favicon.png"
      type="image/svg"
    />
<style>
/* #email-input,#name-input,#password-input1,#password-input2{
 text-align: center;

} */
.invalid-feedback{
  color: red;
  font-size: 12px;
  font-weight: bold;
  margin-top: 10px;
  border-radius:1px #fff ;
}
.invalid-feedbackpassword{
  color: red;
  font-size: 12px;
  font-weight: bold;
  margin-top: 10px;
  border-radius:1px #fff ;
  display: block; 
  /* background-color: ; */
}
</style>
    <!-- ===== All CSS files ===== -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">

    <link rel="stylesheet" href="../assets/css/bootstrap.min.css" />
    <link rel="stylesheet" href="../assets/css/animate.css" />
    <link rel="stylesheet" href="../assets/css/lineicons.css" />
    <link rel="stylesheet" href="../assets/css/ud-styles.css" />
  </head>
    <!-- ====== Header Start ====== -->
    <header class="ud-header">
      <div class="container">
        <div class="row">
          <div class="col-lg-12">
            <nav class="navbar navbar-expand-lg">
              <a class="navbar-brand" href="index.php">
                <img src="../assets/images/logo/favicon.png" alt="Logo" />
                <i class="bi bi-arrow-right-circle-fill" style="font-size: larger; color:yellow;"></i>

              </a>
              <button class="navbar-toggler">
                <span class="toggler-icon"> </span>
                <span class="toggler-icon"> </span>
                <span class="toggler-icon"> </span>
              </button>

          
            </nav>
          </div>
        </div>
      </div>
    </header>
    <!-- ====== Header End ====== -->
    <!-- START PAGE -->
<?php
if(isset($_GET['forget'])&&$_GET['forget']=="pass"){

    ?>
    <!-- ====== Banner Start ====== -->
    <section class="ud-page-banner">
      <div class="container">
        <div class="row">
          <div class="col-lg-12">
            <div class="ud-banner-content">
            <h1> طلب تغيير كلمة السر</h1>
            <h1> يجب ادخال اسمك والحسابك </h1>
            </div>
          </div>
        </div>
      </div>
    </section>
    <!-- ====== Banner End ====== -->
   <!-- ====== Login Start ====== -->
    <section class="ud-login">
      <div class="container">
     
        <div class="row">
          <div class="col-lg-12">
            <div class="ud-login-wrapper">
            <?php
              include("../auth/alert.php");
              ?>
              <div class="ud-login-logo">
                <img src="../assets/images/logo/login.png" style="max-height: 200px;"  alt="logo" />
              </div>
                <form class="ud-login-form" action="<?php echo htmlspecialchars("lookat_account.php"); ?>" method="post" enctype="multipart/form-data">
                <div class="ud-form-group">
                   
                    </div>
                    <div class="ud-form-group">
                    <input
                        type="email"
                        name="email"
                        placeholder="ادخل الايميل"
                    />
                    </div>
                    <div class="ud-form-group">
                    <button type="submit" name="lookfor" class="ud-main-btn w-100">طلب تغيير كلمة المرور</button>
                    </div>
                </form>

                        
                <p class="signup-option">
                لدي حساب <a href="../index.php">العودة لاختيار خدمة</a>
                </p>
                <p class="forget-pass">
                لدي حساب  <a href="../create_account.php">العودة لانشاء حساب</a>
                </p>
                </div>
            </div>
            </div>
        </div>
        </section>
        <!-- ====== Login End ====== -->
<!-- ====== Back To Top Start ====== -->
<a href="javascript:void(0)" class="back-to-top">
      <i class="lni lni-chevron-up"> </i>
    </a>
    <!-- ====== Back To Top End ====== -->
    <!-- ====== All Javascript Files ====== -->
    <script src="../assets/js/input.js"></script>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>

    <script src="../assets/js/bootstrap.bundle.min.js"></script>
    <script src="../assets/js/wow.min.js"></script>
    <script src="../assets/js/main.js"></script>
  </body>
</html>

<?php
}else{
    header("location:../login.php");
}
?>
    
