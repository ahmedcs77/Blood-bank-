<?php
// setcookie('OTP');
session_start();
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // if(isset($_POST['type']))
                    if(!empty($_POST ['email']&&$_POST['name']&&$_POST['id']&&$_POST['page'])){
                        // echo"<pre>TO<hr>";
                        // print_r($_SESSION);
                        //     echo"<pre>";
                        // // echo"isset All pramteres form lookat<br>";
                                        // if (isset($_POST['name'] )&&isset($_SESSION['email'])&& isset($_SESSION['id']))  { 
                                            // echo "is set session Founds All <br>";

                                            if($_POST['page']==="send.php"){
                                                // echo "is set POST Founds Pages <br>";
                                        // _____________ start of form sender to email
                                        $min = 1000; // تأكد من أن الرقم العشوائي مكون من 4 أرقام على الأقل
                                        $max = 9999;
                                        $otp = rand($min, $max);
                                        $id= $_POST['id'];
                                        $name = $_POST['name'];
                                        $to = $_SESSION['email'];
                                        $newotp=md5($otp);
                                         $type= $_POST['type'];       
                                        // قيمة قيمة كود التحقق مشفرة 
                                        // تعيين قيمة OTP في كعكة لمدة دقيقتين
                                        

                                                    //start function send email 
                                        
                                                    //  
                                                          //end counters                            

                                                    //enddddddddddddddddddd

                                                    if (isset($_SESSION['counters'])){
  
                                                        if ($_SESSION['counters']==1){
                                                      
                                                          function send($to, $name, $otp) {
                                                            define("GMAIL", "blood00bank@gmail.com");
                                                            //
                                                            $subject = "ارسال الكود التحقق من بنك الدم اليمني";
                                                            $what="1إعادة تعيين كلمه المرور";
                                                            $message = file_get_contents('send_to_email.html');
                                                            $message = str_replace('[name]', $name, $message);
                                                            $message = str_replace('[what]', $what, $message);
                                                            $message = str_replace('[otp]', $otp, $message);
                                                        
                                                            $from = GMAIL;
                                                            
                                                            $headers = "From: $from\r\n";
                                                            $headers .= "X-Mailer: PHP/" . phpversion() . "\r\n";
                                                            $headers .= "MIME-Version: 1.0\r\n";
                                                            $headers .= "Content-Type: text/html; charset=UTF-8\r\n";
                                                          //Adddddddddddddddddd
                                                          
                                                            
                                                            return mail($to, $subject, $message, $headers);
                                                        
                                                          }
                                                          $_SESSION['counters'] = 2;
                                                        }
                                                        else if ($_SESSION['counters']==2){
                                                          $_SESSION['counters'] = 3;
                                                          function send($to, $name, $otp) {
                                                            define("GMAIL", "blood00bank@gmail.com");
                                                            //
                                                            $subject = "ارسال الكود التحقق من بنك الدم اليمني";
                                                            $what="2إعادة تعيين كلمه المرور";
                                                            $message = file_get_contents('send_to_email.html');
                                                            $message = str_replace('[name]', $name, $message);
                                                            $message = str_replace('[what]', $what, $message);
                                                            $message = str_replace('[otp]', $otp, $message);
                                                        
                                                            $from = GMAIL;
                                                            
                                                            $headers = "From: $from\r\n";
                                                            $headers .= "X-Mailer: PHP/" . phpversion() . "\r\n";
                                                            $headers .= "MIME-Version: 1.0\r\n";
                                                            $headers .= "Content-Type: text/html; charset=UTF-8\r\n";
                                                          //Adddddddddddddddddd
                                                          
                                                            
                                                            return mail($to, $subject, $message, $headers);
                                                        
                                                          }
                                                        }else if($_SESSION['counters']===3){
                                                        
                                                          function send($to, $name, $otp) {
                                                            define("GMAIL", "blood00bank@gmail.com");
                                                            //
                                                            $subject = "ارسال الكود التحقق من بنك الدم اليمني";
                                                            $what="3إعادة تعيين كلمه المرور";
                                                            $message = file_get_contents('send_to_email.html');
                                                            $message = str_replace('[name]', $name, $message);
                                                            $message = str_replace('[what]', $what, $message);
                                                            $message = str_replace('[otp]', $otp, $message);
                                                        
                                                            $from = GMAIL;
                                                            
                                                            $headers = "From: $from\r\n";
                                                            $headers .= "X-Mailer: PHP/" . phpversion() . "\r\n";
                                                            $headers .= "MIME-Version: 1.0\r\n";
                                                            $headers .= "Content-Type: text/html; charset=UTF-8\r\n";
                                                          //Adddddddddddddddddd
                                                          
                                                            
                                                            return mail($to, $subject, $message, $headers);
                                                        
                                                          }
                                                        
                                                        }else{
                                                          echo $_SESSION['counters'];
                                                          header('warning.php');
                                                        }
                                                      
                                                      }
                                                    
                                                    
                                                    //end function send email 
            
             
             
             
                                       
                                       
                                    // حدد البيانات التي تريد إرسالها
                                   
                                //    $username= $_POST['name'];
                                //    $emai= $_POST['email'];
                          
                        
// ADD Counters to send message
                      
                                                
                                //  end of form sender to email
                                
                                
                            
 
 
 
 
 
 
}//end if($_POST['page']==="lookat_account.php"){
 else{// else if($_POST['page']==="lookat_account.php"){
                    // echo "Error ::: 403 Not Found Acsess Data by request browser  - please try again<br>";
                    echo "Error ::: 403 Not Found Acsess Data by request browser MEHODES - please try again<br>";
           
           
           
                }

//     }//end if (isset($_POST['name'] )&&isset($_SESSION['email'])&& isset($_SESSION['id'])) { 
//  else { //else if (isset($_POST['name'] )&&isset($_SESSION['email'])&& isset($_SESSION['id'])) { 
//     // echo "Error ::: 402 Not Found Data by request browser  - please try again<br>";
//     echo "Error ::: 402 Not Found Data by request browser POST  is empty- please try again<br>";
// }//end else    if (isset($_POST['name'] )&&isset($_SESSION['email'])&& isset($_SESSION['id']))

}//end if(!empty($_POST ['email']&&$_POST['name']&&$_SESSION['id']&&$_POST['page']))

else{//else if(!empty($_POST ['email']&&$_POST['name']&&$_SESSION['id']&&$_POST['page']))
    echo"Error ::: 401 Not Found Data by request browser   - please try again";
 }//end else if(!empty($_POST ['email']&&$_POST['name']&&$_SESSION['id']&&$_POST['page']))
        // header('Location: waiting.php');
        // exit(); // إنهاء التنفيذ بعد إعادة التوجيه

    }//// end if ($_SERVER['REQUEST_METHOD'] === 'POST') {
     else {// else if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        echo " Error ::: 400 Not Found by request browser  - please try again";
               }//end else if ($_SERVER['REQUEST_METHOD'] === 'POST') {
               
    // }


?>
