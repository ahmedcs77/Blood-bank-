<?php
session_start();
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
if (isset($_POST['page'])&&isset($_POST['name'] )&&isset($_POST['OTP']))
{//bgin if (isset($_POST['page'])&&isset($_POST['name'] )&&isset($_POST['OTP']))

$id=$_POST['id'];
$page=$_POST['page'];
$name=$_POST['name'];
$email=$_POST['email'];
$type=$_POST['type'];
$newotp=$_POST['OTP'];
$status=$_POST['status'];
if($_POST['status']==5){
if(isset($_COOKIE['OTP'])){


?>

<!DOCTYPE html>
    <html lang="ar">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>blood</title>
        <link rel="stylesheet" href="styles.css">
    </head>
    <body>
        <div class="container">
            <div class="header">
                <h1>بنك الدم اليمني</h1>
                <h2>يرجى ادخال الكود الموجود الي حساب التالي</h2>
                <h3 id="email"><?php echo $email ; ?></h3>
            </div>
            
            <div class="content">
                <form action="<?php echo htmlspecialchars("ckvalidation.php") ;  ?>" method="post">
                <input type="text" name ="input_otp" id="otp-input" placeholder="Enter OTP" maxlength="4">
                <input type="hidden" name ="name" value="<?php echo $name;?>">
                <input type="hidden" name ="id" value="<?php echo $id;?>">
                <input type="hidden" name ="email" value="<?php echo $email;?>">
                <input type="hidden" name ="status" value="<?php echo $status;?>">
                <input type="hidden" name ="type" value="<?php echo $type;?>">
                <button id="verify-btn" onclick="verifyOTP()">Verify</button>
                <button id="verify-btn" onclick="sendOTP()">أعادة ارسال</button>
                <?php    echo "عدد االمرات";?>
            </form>
                <div id="timer" class="timer">الوقت المتبقي للادخال: 2:00</div>
            </div>
        </div>
        <script src="script.js"></script>
    </body>
    </html>
<?php
    echo '<form id="redirect-form-send" action="' . htmlspecialchars("validation.php") . '" method="post">';
$page="send.php";
$data=array(
    'page'=>$page,
    'id'=>$id,
    'name'=>$name,
    'email'=>$email,
    'type'=>$type,
);

     // هنا يمكنك إضافة البيانات إلى النموذج
     foreach ($data as $key => $value) {
        echo '<input type="hidden" name="' . $key . '" value="' . $value . '">';
    }

    echo '</form>';
    // echo '';
}else{

    echo"لقد انتهاء الوقت المسموح لادخال الكود";

}

}//end status ==2
else{
    echo")))))))))))))))))))******";
}


}//end if (isset($_POST['page'])&&isset($_POST['name'] )&&isset($_POST['OTP']))
else{
    echo":<KKKKKKKKKKKKK<<KKKVK";
}
}//end if($SERVER['REQUEST_METHOD'] === 'POST)

else{
    echo"ERROR NOT requert and not requert POSmbvhvjhvjhT <br>";
}

?>