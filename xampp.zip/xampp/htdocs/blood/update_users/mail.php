<?php
if (isset($_SESSION['counters'])){
  
  if ($_SESSION['counters']==1){

    function send($to, $name, $otp) {
      define("GMAIL", "blood00bank@gmail.com");
      //
      $subject = "ارسال الكود التحقق من بنك الدم اليمني";
      $what="1إعادة تعيين كلمه المرور";
      $message = file_get_contents('send_to_email.html');
      $message = str_replace('[name]', $name, $message);
      $message = str_replace('[what]', $what, $message);
      $message = str_replace('[otp]', $otp, $message);
  
      $from = GMAIL;
      
      $headers = "From: $from\r\n";
      $headers .= "X-Mailer: PHP/" . phpversion() . "\r\n";
      $headers .= "MIME-Version: 1.0\r\n";
      $headers .= "Content-Type: text/html; charset=UTF-8\r\n";
    //Adddddddddddddddddd
    
      
      return mail($to, $subject, $message, $headers);
  
    }
    $_SESSION['counters'] = 2;
  }
  else if ($_SESSION['counters']==2){
    $_SESSION['counters'] = 3;
    function send($to, $name, $otp) {
      define("GMAIL", "blood00bank@gmail.com");
      //
      $subject = "ارسال الكود التحقق من بنك الدم اليمني";
      $what="2إعادة تعيين كلمه المرور";
      $message = file_get_contents('send_to_email.html');
      $message = str_replace('[name]', $name, $message);
      $message = str_replace('[what]', $what, $message);
      $message = str_replace('[otp]', $otp, $message);
  
      $from = GMAIL;
      
      $headers = "From: $from\r\n";
      $headers .= "X-Mailer: PHP/" . phpversion() . "\r\n";
      $headers .= "MIME-Version: 1.0\r\n";
      $headers .= "Content-Type: text/html; charset=UTF-8\r\n";
    //Adddddddddddddddddd
    
      
      return mail($to, $subject, $message, $headers);
  
    }
  }else if($_SESSION['counters']===3){
  
    function send($to, $name, $otp) {
      define("GMAIL", "blood00bank@gmail.com");
      //
      $subject = "ارسال الكود التحقق من بنك الدم اليمني";
      $what="3إعادة تعيين كلمه المرور";
      $message = file_get_contents('send_to_email.html');
      $message = str_replace('[name]', $name, $message);
      $message = str_replace('[what]', $what, $message);
      $message = str_replace('[otp]', $otp, $message);
  
      $from = GMAIL;
      
      $headers = "From: $from\r\n";
      $headers .= "X-Mailer: PHP/" . phpversion() . "\r\n";
      $headers .= "MIME-Version: 1.0\r\n";
      $headers .= "Content-Type: text/html; charset=UTF-8\r\n";
    //Adddddddddddddddddd
    
      
      return mail($to, $subject, $message, $headers);
  
    }
  
  }else{
    echo $_SESSION['counters'];
    header('warning.php');
  }

}else{
  $_SESSION['counters']=1;
}

include'../auth/db_connect.php';

 $sql = "UPDATE `users` SET `verify`='$newotp' WHERE  id=$id;";
 if ($conn->query($sql) === TRUE) {
    echo "تم تحديث البيانات بنجاح!";
} else {
    echo "حدث خطأ أثناء تحديث البيانات: nottt" ;


}// إعداد البيان المُحضَّر



?>