
<html lang="ar" dir="rtl">
<?php  
// include '../auth/db_connect.php';
session_start();
    
             
?>
<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>blood</title>

    <!--====== Favicon Icon ======-->
    <link rel="shortcut icon" href="../../assets/images/icon1.png" type="image/svg" />

    <!-- ===== All CSS files ===== -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <link rel="stylesheet" href="../../assets/css/bootstrap.min.css" />
    <link rel="stylesheet" href="../../assets/css/animate.css" />
    <link rel="stylesheet" href="../../assets/css/lineicons.css" />
    <link rel="stylesheet" href="../../assets/css/ud-styles.css" />
    <link rel="stylesheet" href="../../assets/fonts/all.min.css" />
    <link rel="stylesheet" href="../../assets/fonts/all.css" />
   
    <style>
    .search-box {
      display: none; /* يكون مخفياً افتراضياً */
    }
  </style>
  <script>
    function toggleSearchBox() {
      var searchBox = document.getElementById("search-box");
      if (searchBox.style.display === "none") {
        searchBox.style.display = "block"; // يعرض مربع البحث
      } else {
        searchBox.style.display = "none"; // يخفي مربع البحث
      }
    }

    </script>
</head>

<body>
 

    
  <!-- start search<button type="button" class="btn btn-success">Success</button>
 -->
 <div id="showbox" class="btn-search">
    <button class="btn btn-danger text-center " onclick="toggleSearchBox()"><i class="fa-solid fa-magnifying-glass"></i>
البحث</button>
</div>
  <div id="search-box" class="search-box">
    <form method="GET" action="search.php">
      <div class="col-4">
    <div class="input-group  mb-3 col-2">
  <span class="input-group-text " id="basic-addon1"><i class="fa-solid fa-magnifying-glass"></i></span>
  <input type="text" class="form-control" name="query" placeholder="search...." aria-label="search" aria-describedby="basic-addon1"><br>
  <!-- <input type="radio" name="search" value="1" checked id="">
      <input type="radio" name="search" value="2" id=""> -->
    </div></div>
<div class="form-check form-check-inline">
  <input class="form-check-input" type="radio" name="searchby" id="inlineRadio1" value="1" checked>
  <label class="form-check-label" for="inlineRadio1">المستشفى</label>
</div>
<div class="form-check form-check-inline">
  <input class="form-check-input" type="radio" name="searchby" id="inlineRadio2" value="2">
  <label class="form-check-label" for="inlineRadio2">المتبرع</label>
</div>
<div class="form-check form-check-inline">
  <input class="form-check-input" type="radio" name="searchby" id="inlineRadio2" value="3">
  <label class="form-check-label" for="inlineRadio2">المريض</label>
</div>
<div class="form-check form-check-inline">
  <input class="form-check-input" type="radio" name="searchby" id="inlineRadio2" value="4">
  <label class="form-check-label" for="inlineRadio2">الدكتور</label>
</div>
<div class="form-check form-check-inline">
  <input class="form-check-input" type="radio" name="searchby" id="inlineRadio2" value="5">
  <label class="form-check-label"  for="inlineRadio2">المختبر</label>
</div>

      <!-- <input type="radio" name="search" value="4" id="">
      <input type="radio" name="search" value="5" id=""> -->
      <button type="submit" name="search"onclick="show_btn_search()" class="btn btn-danger from-control">Search</button>

      <!-- <button type="submit"name="search-box">ابحث</button>  -->
    </form>
    <!-- end Search -->
  </div>
   

  <h2 class="text-center">جدول الحجوزات</h2><br>

  <!-- Start table  -->
  <div class="table-responsive">
        <table class="table">
            <thead>
                <tr>
                  <!-- 0 -->
                    <th scope="col">الرقم</th>
                                <!-- 1 -->
                    <!-- <th scope="col">اسم المستشفى</th> -->
                                <!-- 2 -->
                    <th scope="col">اسم المختبر</th> 
                                <!-- 3 -->
                    <th scope="col">اسم المريض</th>
                                <!-- 4     -->
                    <th scope="col">فصيلة دم المريض</th>
                                  <!-- 5 -->
                    <th scope="col">اسم المتبرع</th>
                                  <!-- 6 -->
                    <th  scope="col">فصيلة دم المتبرع</th>
                                    <!-- 7 -->
                                    <!-- 9 -->
                    <th scope="col" class="text-center bg-warning">وقت الحجز</th>
                                    <!-- 10 -->
                    
                    <th scope="col"class="text-center">وقت الحضور</th>
                    
                    <th scope="col"> اسم الدكتور </th>

                                    <!-- 8 -->
                    <th scope="col">رقم جوال الدكتور</th>
                                    <!-- 11 -->
                    <th scope="col"> الحالةالطلب </th>
                                    <!-- 12 -->                    
                    <!-- <th scope="col"> الحالةالمختبر </th> -->
                    <!-- <th   scope="col"> </th> -->

                  
                </tr>
            </thead>
            <tbody>
                <!-- the code pring data -->
                <?php

              include '../auth/alert.php';
              include '../auth/db_connect.php';
                if (isset($_SESSION['hos_id'])) {
              // echo "hello world";exit();

                    $h_id =$_SESSION['hos_id'];
                    $sql = "SELECT 
	d_fp.id AS donation_id,
    l.name AS laboratory_name, 
    p.firste_name AS patient_first_name,
    p.med_name AS patient_med_name,
    p.last_name AS patient_last_name,
    p.blood_group AS patient_blood,
    
    d.firste_name AS donor_first_name,
    d.med_name AS donor_med_name,
    d.last_name AS donor_last_name,
    d.blood_group AS donor_blood,
    
    doc.name AS doctor_name,
    doc.phone AS doc_phone,

    f.f_num AS floor_number,
    d_fp.check as Checking
FROM 
    hospitals h
    JOIN laboratory l ON l.h_id = h.h_id
    JOIN donate_for_patient d_fp ON d_fp.l_id = l.l_id
    JOIN patient p ON p.p_id = d_fp.p_id
    JOIN donors d ON d.d_id = d_fp.d_id
    JOIN doctor doc ON doc.l_id = l.l_id
    JOIN floor f ON f.f_id = l.f_id
WHERE 
    h.h_id =". $h_id ." and d_fp.check=". 0 ."";
      // echo "heka;rjf";exit();
                    $result = mysqli_query($conn, $sql);
                    $contt = 1;
                    if ($result) {
                        while ($row = mysqli_fetch_row($result)) {
                ?>
                            <tr>
                                <th scope="row"><?php echo $contt++; ?></th>
                                <!--name hospital  -->
                                <th scope="row"><?php echo $row[1]; ?></th>
                                <!-- Name laboratory -->
                              
                                <!-- name patient -->
                                <th scope="row"><?php echo $row[2] . " " . $row[3] . " ".$row[4] ; ?></th>
                               <!-- 	blood_group -->
                                   <th scope="row"><?php if ($row[5]==1) {
                                        echo"A+";   }elseif ($row[5]==2) {
                                        echo"A-";   }elseif ($row[5]==3) {
                                        echo"B+";   }elseif ($row[5]==4) {
                                        echo"B-";   }elseif ($row[5]==5) {
                                        echo"O+";   }elseif ($row[5]==6) {
                                        echo"O-";   }elseif ($row[5]==7) {
                                        echo"AB+";  }elseif ($row[5]==8) {
                                        echo"AB-";  }    ?></th>
                               
                                <!-- name   patient-->
                                <th scope="row"><?php echo $row[6]. " " . $row[7]. " " . $row[8]; ?></th>
                                
                                
                                <!-- 	blood_group donors -->
                                
                               
                                <th scope="row">   <?php if ($row[9]==1) {
                                        echo"A+";   }elseif ($row[9]==2) {
                                        echo"A-";   }elseif ($row[9]==3) {
                                        echo"B+";   }elseif ($row[9]==4) {
                                        echo"B-";   }elseif ($row[9]==5) {
                                        echo"O+";   }elseif ($row[9]==6) {
                                        echo"O-";   }elseif ($row[9]==7) {
                                        echo"AB+";  }elseif ($row[9]==8) {
                                        echo"AB-";  }    ?></th>
                               <!-- Date Create -->
                               <th scope="row"class="text-center bg-warning" >
                              </th>
                                <!-- Date Booking -->
                                <th scope="row"class="text-center ">
                                  </th>
                                <!-- Name Doctor -->
                                <th scope="row"><?php echo $row[10]; ?></th>
                                <!-- Name Doctor -->
                                <th scope="row"><?php echo $row[11]; ?></th>
                                
                                <!-- Status-request -->
                                <th><?php if($row[13]==0){ 
                                  ?>
                                   <a href="accept.php?id=<?php echo $row[0]; ?>" class='  text-center btn-warning'>الموافقة</a>
                                   <?php
                                }
                                 ?></th>
                            
        
                            </tr>
                <?php
                        }
                    } else {
                        echo "حدث خطأ في استعلام قاعدة البيانات.";
                    }
                }
                // echo"error";exit();
                mysqli_close($conn);
                ?>
                <!-- ====== Back To Top Start ====== -->
                <a href="javascript:void(0)" class="back-to-top">
                    <i class="lni lni-chevron-up"> </i>
                </a>
                <!-- ====== Back To Top End ====== -->

                <!-- ====== All Javascript Files ====== -->
                <script src="../../assets/js/all.js"></script>
                <script src="../../assets/js/bootstrap.bundle.min.js"></script>
                <script src="../../assets/js/wow.min.js"></script>
                <script src="../../assets/js/main.js"></script>
                <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
                <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js" integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous"></script>
                <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.min.js" integrity="sha384-BBtl+eGJRgqQAUMxJ7pMwbEyER4l1g+O15P+16Ep7Q9Q+zqX6gSbd85u4mG4QzX+" crossorigin="anonymous"></script>
</body>

</html>
<!-- الكود الباقي للصفحة -->