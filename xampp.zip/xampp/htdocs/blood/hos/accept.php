<?php
session_start();
include '../auth/db_connect.php';
    $id=$_GET['id'];
    $q="update donate_for_patient set donate_for_patient.check =". 1 ." where id=" . $id;
    // echo $q;exit();
    $result=mysqli_query($conn,$q);
$_SESSION['success']="تمت العملية ";
    header("Location:reservationsbyhos.php");
    
?>